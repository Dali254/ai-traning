import { NextResponse } from 'next/server';
import { query, queryOne } from '@/lib/db';
import { requireUser, AuthError } from '@/lib/session';
import { getBool, getNumber } from '@/lib/settings';
import { stkPush, normalisePhone, MpesaError } from '@/lib/mpesa';

export const runtime = 'nodejs';

/**
 * Start a membership payment. Creates a pending mpesa_transactions row and
 * fires the STK push. The payment only becomes 'paid' when the signed
 * webhook arrives — see api/mpesa/webhook.
 */
export async function POST(req: Request) {
  let user;
  try {
    user = await requireUser();
  } catch (err) {
    const status = err instanceof AuthError ? err.status : 401;
    return NextResponse.json({ error: 'Not signed in' }, { status });
  }

  if (!(await getBool('paid_membership', false))) {
    return NextResponse.json(
      { error: 'Membership is currently free — no payment needed' },
      { status: 400 }
    );
  }

  if (user.membership_status === 'paid') {
    return NextResponse.json({ error: 'Membership is already active' }, { status: 400 });
  }

  const fee = await getNumber('membership_fee', 500);
  if (fee <= 0) {
    return NextResponse.json({ error: 'Membership fee is not configured' }, { status: 400 });
  }

  // Let the member pay from a different number than the one on file.
  let phone = user.phone;
  try {
    const body = (await req.json().catch(() => ({}))) as { phone?: string };
    if (body.phone) phone = normalisePhone(body.phone);
  } catch (err) {
    if (err instanceof MpesaError) {
      return NextResponse.json({ error: err.message }, { status: 400 });
    }
  }

  // Reuse a still-pending attempt from the last 2 minutes rather than
  // spamming the member's phone with prompts.
  const recent = await queryOne<{ transaction_id: string }>(
    `SELECT transaction_id FROM mpesa_transactions
      WHERE user_id = $1 AND purpose = 'membership' AND status = 'pending'
        AND created_at > now() - interval '2 minutes'
      ORDER BY created_at DESC LIMIT 1`,
    [user.id]
  );
  if (recent?.transaction_id) {
    return NextResponse.json({
      success: true,
      transactionId: recent.transaction_id,
      message: 'A payment prompt was already sent — check your phone',
      reused: true,
    });
  }

  const reference = `MEM-${user.id}-${Date.now().toString(36).toUpperCase()}`;

  let result;
  try {
    result = await stkPush({ amount: fee, phone, reference });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'M-Pesa is not configured';
    console.error('[mpesa:stk]', message);
    return NextResponse.json({ error: message }, { status: 500 });
  }

  if (!result.success) {
    await query(
      `INSERT INTO mpesa_transactions
         (user_id, direction, purpose, phone, amount, reference, status,
          result_desc, raw_request)
       VALUES ($1,'in','membership',$2,$3,$4,'failed',$5,$6)`,
      [user.id, phone, fee.toFixed(2), reference, result.error, JSON.stringify(result.raw)]
    );
    return NextResponse.json({ error: result.error }, { status: 502 });
  }

  await query(
    `INSERT INTO mpesa_transactions
       (transaction_id, user_id, direction, purpose, phone, amount, reference,
        status, raw_request)
     VALUES ($1,$2,'in','membership',$3,$4,$5,'pending',$6)
     ON CONFLICT (transaction_id) DO NOTHING`,
    [
      result.transactionId,
      user.id,
      phone,
      fee.toFixed(2),
      reference,
      JSON.stringify(result.raw),
    ]
  );

  await query(
    `UPDATE users SET membership_status = 'pending_payment'
      WHERE id = $1 AND membership_status NOT IN ('paid','suspended')`,
    [user.id]
  );

  return NextResponse.json({
    success: true,
    transactionId: result.transactionId,
    message: result.message,
    amount: fee,
    phone,
  });
}
