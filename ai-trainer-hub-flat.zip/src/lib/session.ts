import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import bcrypt from 'bcryptjs';
import { queryOne } from './db';

const COOKIE = 'ath_session';
const MAX_AGE_SEC = 60 * 60 * 24 * 14; // 14 days

function secret(): Uint8Array {
  const s = process.env.SESSION_SECRET;
  if (!s || s.length < 32) {
    throw new Error(
      'SESSION_SECRET must be set to at least 32 characters. Generate one with:\n' +
        '  node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"'
    );
  }
  return new TextEncoder().encode(s);
}

export type SessionUser = {
  id: number;
  full_name: string;
  phone: string;
  email: string;
  role: 'member' | 'admin';
  membership_status: 'free' | 'paid' | 'pending_payment' | 'suspended';
  account_status: 'active' | 'suspended';
  level_id: number | null;
  points: number;
  accuracy: string;
  tasks_completed: number;
  streak_days: number;
  referral_code: string;
  hide_name: boolean;
};

// ─── Passwords ──────────────────────────────────────────────────────────
export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 11);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

// ─── Cookie ─────────────────────────────────────────────────────────────
export async function createSession(userId: number): Promise<void> {
  const token = await new SignJWT({ uid: userId })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(`${MAX_AGE_SEC}s`)
    .sign(secret());

  const jar = await cookies();
  jar.set(COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: MAX_AGE_SEC,
  });
}

export async function destroySession(): Promise<void> {
  const jar = await cookies();
  jar.delete(COOKIE);
}

async function readUserId(): Promise<number | null> {
  const jar = await cookies();
  const token = jar.get(COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret());
    const uid = payload.uid;
    return typeof uid === 'number' ? uid : null;
  } catch {
    return null;
  }
}

const USER_FIELDS = `
  id, full_name, phone, email, role, membership_status, account_status,
  level_id, points, accuracy, tasks_completed, streak_days, referral_code, hide_name
`;

/** Current user, or null when not signed in. Never throws. */
export async function getUser(): Promise<SessionUser | null> {
  const uid = await readUserId();
  if (!uid) return null;
  const user = await queryOne<SessionUser>(
    `SELECT ${USER_FIELDS} FROM users WHERE id = $1 AND account_status = 'active'`,
    [uid]
  );
  return user;
}

/** Current user, or throw. Use in API routes behind auth. */
export async function requireUser(): Promise<SessionUser> {
  const user = await getUser();
  if (!user) throw new AuthError('Not signed in', 401);
  return user;
}

export async function requireAdmin(): Promise<SessionUser> {
  const user = await requireUser();
  if (user.role !== 'admin') throw new AuthError('Admin access required', 403);
  return user;
}

export class AuthError extends Error {
  status: number;
  constructor(message: string, status = 401) {
    super(message);
    this.name = 'AuthError';
    this.status = status;
  }
}
