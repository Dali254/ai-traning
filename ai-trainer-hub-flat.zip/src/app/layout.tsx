import type { Metadata, Viewport } from 'next';
import './globals.css';

/**
 * Inter is loaded with a stylesheet <link> rather than `next/font/google`.
 * next/font self-hosts the files, which is marginally faster, but it fetches
 * from Google at BUILD time — so a slow or blocked Google Fonts makes the
 * whole Vercel deploy fail. A link tag moves that to the browser, where a
 * hiccup just falls back to system-ui.
 */
export const metadata: Metadata = {
  title: 'AI Trainer Hub — Train AI. Complete Tasks. Earn Rewards.',
  description:
    'Join our AI training community, complete intelligent evaluation tasks and earn rewards based on your performance. Paid to M-Pesa.',
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: '#06070d',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
