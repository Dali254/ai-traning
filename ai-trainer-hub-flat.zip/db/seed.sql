-- ═══════════════════════════════════════════════════════════════════════
-- Default data. Run AFTER schema.sql:
--   psql "$DATABASE_URL" -f db/seed.sql
--
-- Every value here is editable from the admin dashboard afterwards.
-- ═══════════════════════════════════════════════════════════════════════

-- ─── Member levels ───────────────────────────────────────────────────────
INSERT INTO member_levels (position, name, required_points, required_tasks, required_accuracy, reward_multiplier)
VALUES
  (1, 'New Trainer',       0,    0,   0,    1.00),
  (2, 'Trainee',           200,  20,  70.0, 1.00),
  (3, 'Verified Trainer',  1000, 100, 80.0, 1.10),
  (4, 'Advanced Trainer',  3000, 250, 88.0, 1.20),
  (5, 'Expert Trainer',    8000, 600, 93.0, 1.35)
ON CONFLICT (position) DO NOTHING;

-- ─── Difficulty levels — the reward ladder ──────────────────────────────
INSERT INTO difficulty_levels (position, name, description, reward, bonus, min_member_level, points_awarded)
VALUES
  (1, 'Beginner',     'Short, simple judgements',                5.00,  0.00, 1, 5),
  (2, 'Easy',         'Straightforward evaluation',             10.00,  0.00, 1, 10),
  (3, 'Intermediate', 'Requires careful reading',               25.00,  0.00, 2, 20),
  (4, 'Advanced',     'Multi-step reasoning or verification',   50.00,  5.00, 3, 40),
  (5, 'Expert',       'Safety, policy and edge-case judgement', 100.00, 10.00, 4, 80)
ON CONFLICT (position) DO NOTHING;

-- ─── AI models. logo_path is NULL → neutral SVG mark until admin uploads ─
INSERT INTO ai_models (slug, name, accent, sort_order, visible)
VALUES
  ('chatgpt', 'ChatGPT', '#19C79B', 1, true),
  ('claude',  'Claude',  '#E58D6A', 2, true),
  ('gemini',  'Gemini',  '#6BA4F8', 3, true)
ON CONFLICT (slug) DO NOTHING;

-- ─── Settings ───────────────────────────────────────────────────────────
INSERT INTO settings (key, value, value_type, category, label) VALUES

  -- Platform
  ('platform_name',        'AI Trainer Hub',      'string',  'platform', 'Platform name'),
  ('currency',             'KES',                 'string',  'platform', 'Currency code'),
  ('timezone',             'Africa/Nairobi',      'string',  'platform', 'Timezone'),
  ('support_email',        '',                    'string',  'platform', 'Support email'),
  ('support_phone',        '',                    'string',  'platform', 'Support phone'),

  -- Membership
  ('paid_membership',      'false',               'boolean', 'membership', 'Require paid membership'),
  ('membership_fee',       '500',                 'number',  'membership', 'Membership fee'),
  ('membership_desc',      'AI Trainer Hub membership', 'string', 'membership', 'Payment description'),

  -- Reward mode: 'fixed' takes the difficulty reward; 'percentage' applies a rate
  ('reward_mode',          'fixed',               'string',  'rewards', 'Reward mode'),
  ('reward_percentage',    '10',                  'number',  'rewards', 'Reward percentage'),
  ('hold_rewards_pending', 'true',                'boolean', 'rewards', 'Hold rewards as pending until scored'),

  -- Commission / bonus switches. Each can be turned off without touching code.
  ('commission_task',          'true',  'boolean', 'commissions', 'Task completion commission'),
  ('commission_task_rate',     '0',     'number',  'commissions', 'Task commission %'),
  ('commission_training',      'false', 'boolean', 'commissions', 'AI training commission'),
  ('commission_training_rate', '5',     'number',  'commissions', 'Training commission %'),
  ('bonus_difficulty',         'true',  'boolean', 'bonuses', 'Difficulty bonus'),
  ('bonus_performance',        'true',  'boolean', 'bonuses', 'Performance bonus'),
  ('bonus_performance_rate',   '10',    'number',  'bonuses', 'Performance bonus %'),
  ('bonus_daily',              'true',  'boolean', 'bonuses', 'Daily task bonus'),
  ('bonus_daily_amount',       '10',    'number',  'bonuses', 'Daily bonus amount'),
  ('bonus_weekly',             'true',  'boolean', 'bonuses', 'Weekly performance bonus'),
  ('bonus_weekly_amount',      '50',    'number',  'bonuses', 'Weekly bonus amount'),
  ('bonus_first_task',         'true',  'boolean', 'bonuses', 'First task bonus'),
  ('bonus_first_task_amount',  '20',    'number',  'bonuses', 'First task bonus amount'),
  ('bonus_login',              'false', 'boolean', 'bonuses', 'Daily login bonus'),
  ('bonus_login_amount',       '5',     'number',  'bonuses', 'Login bonus amount'),
  ('bonus_streak',             'true',  'boolean', 'bonuses', 'Completion streak bonus'),
  ('bonus_streak_amount',      '30',    'number',  'bonuses', 'Streak bonus amount'),
  ('bonus_streak_days',        '7',     'number',  'bonuses', 'Streak days required'),
  ('bonus_levelup',            'true',  'boolean', 'bonuses', 'Level-up bonus'),
  ('bonus_levelup_amount',     '100',   'number',  'bonuses', 'Level-up bonus amount'),
  ('bonus_accuracy',           'true',  'boolean', 'bonuses', 'Accuracy bonus'),
  ('bonus_accuracy_amount',    '25',    'number',  'bonuses', 'Accuracy bonus amount'),
  ('bonus_accuracy_min',       '95',    'number',  'bonuses', 'Accuracy bonus threshold %'),
  ('bonus_leaderboard',        'true',  'boolean', 'bonuses', 'Leaderboard bonus'),
  ('bonus_leaderboard_amount', '500',   'number',  'bonuses', 'Leaderboard bonus amount'),
  ('bonus_leaderboard_top',    '10',    'number',  'bonuses', 'Leaderboard bonus top N'),

  -- Referrals
  ('referrals_enabled',    'true',  'boolean', 'referrals', 'Referral system enabled'),
  ('referral_rate',        '5',     'number',  'referrals', 'Referral commission %'),
  ('referral_fixed',       '0',     'number',  'referrals', 'Referral fixed bonus'),
  ('referral_max_earnings','5000',  'number',  'referrals', 'Max referral earnings per member'),

  -- Task rotation
  ('tasks_per_day',        '2',     'number',  'rotation', 'Tasks per member per day'),
  ('recycle_days',         '30',    'number',  'rotation', 'Days before a task can repeat'),
  ('daily_reset_time',     '00:00', 'string',  'rotation', 'Daily reset time (EAT)'),
  ('taskgen_review_first', 'true',  'boolean', 'rotation', 'Hold generated tasks for review'),
  ('taskgen_model',        'claude-sonnet-5', 'string', 'rotation', 'Claude model for generation'),
  ('audit_task_ratio',     '10',    'number',  'rotation', 'Percent of batch that are audit tasks'),

  -- Quality control
  ('min_passing_score',    '60',    'number',  'quality', 'Minimum passing score %'),
  ('low_quality_action',   'reduce','string',  'quality', 'Action on low quality: none|reduce|reject'),
  ('low_quality_rate',     '50',    'number',  'quality', 'Reduced reward % on low quality'),
  ('max_attempts',         '1',     'number',  'quality', 'Default max attempts per task'),

  -- Payouts
  ('payout_cycle',         'monthly','string', 'payouts', 'Payout cycle: daily|weekly|monthly'),
  ('payout_day_of_month',  '30',    'number',  'payouts', 'Monthly payout day'),
  ('payout_day_of_week',   '5',     'number',  'payouts', 'Weekly payout weekday (1=Mon)'),
  ('payout_time',          '18:00', 'string',  'payouts', 'Payout run time (EAT)'),
  ('payout_cutoff_hours',  '24',    'number',  'payouts', 'Request cut-off before run (hours)'),
  ('payout_auto_approve',  'false', 'boolean', 'payouts', 'Settle without manual approval'),
  ('withdrawal_min',       '500',   'number',  'payouts', 'Minimum withdrawal'),
  ('withdrawal_max',       '150000','number',  'payouts', 'Maximum withdrawal'),
  ('withdrawal_fee',       '25',    'number',  'payouts', 'Processing fee'),

  -- Security
  ('max_login_attempts',   '5',     'number',  'security', 'Max failed logins before lockout'),
  ('lockout_minutes',      '15',    'number',  'security', 'Lockout duration (minutes)'),

  -- Leaderboard
  ('leaderboard_metric',   'points','string',  'leaderboard', 'Rank by: points|tasks|accuracy|earnings')

ON CONFLICT (key) DO NOTHING;
