import { redirect } from 'next/navigation';
import { getUser } from '@/lib/session';
import { getSetting } from '@/lib/settings';
import LoginForm from './LoginForm';

export const dynamic = 'force-dynamic';

export default async function LoginPage() {
  const user = await getUser();
  if (user) redirect(user.role === 'admin' ? '/admin' : '/dashboard');

  const platformName = await getSetting('platform_name', 'AI Trainer Hub');
  return <LoginForm platformName={platformName} />;
}
