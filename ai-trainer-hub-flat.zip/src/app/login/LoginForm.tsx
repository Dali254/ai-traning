'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import Icon, { Logo } from '@/components/Icon';

export default function LoginForm({ platformName }: { platformName: string }) {
  const router = useRouter();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const canSubmit = identifier.trim().length > 3 && password.length > 0 && !busy;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!canSubmit) return;
    setBusy(true);
    setError('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: identifier.trim(), password }),
      });
      const data = (await res.json()) as { error?: string; next?: string };
      if (!res.ok) {
        setError(data.error ?? 'Could not sign you in');
        setBusy(false);
        return;
      }
      router.push(data.next ?? '/dashboard');
    } catch {
      setError('Network error. Check your connection and try again.');
      setBusy(false);
    }
  }

  return (
    <main
      style={{
        position: 'relative',
        minHeight: '100dvh',
        display: 'flex',
        flexDirection: 'column',
        maxWidth: 520,
        margin: '0 auto',
      }}
    >
      <div
        className="glow"
        style={{
          top: -170,
          left: -110,
          width: 420,
          height: 420,
          background: 'radial-gradient(circle, rgba(94,92,255,0.28) 0%, rgba(94,92,255,0) 68%)',
        }}
      />

      <header style={{ position: 'relative', zIndex: 2, display: 'flex', alignItems: 'center', gap: 12, padding: '14px 18px' }}>
        <Link
          href="/"
          aria-label="Go back"
          style={{
            width: 36,
            height: 36,
            borderRadius: 12,
            border: '1px solid var(--border-strong)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#c6cbe0',
          }}
        >
          <Icon name="arrow-left" size={15} strokeWidth={2.2} />
        </Link>
      </header>

      <form
        onSubmit={submit}
        style={{
          position: 'relative',
          zIndex: 1,
          flex: 1,
          padding: '30px 18px 0',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 22 }}>
          <Logo size={34} />
          <span style={{ fontSize: 16, fontWeight: 800, letterSpacing: '-0.025em' }}>{platformName}</span>
        </div>

        <h1 style={{ margin: 0, fontSize: 28, fontWeight: 900, letterSpacing: '-0.034em', lineHeight: 1.1 }}>
          Welcome back
        </h1>
        <p style={{ margin: '9px 0 0', fontSize: 12.5, color: '#8e98ae' }}>
          Sign in with your phone number or email.
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 24 }}>
          <div>
            <label htmlFor="identifier" className="lbl">
              PHONE OR EMAIL
            </label>
            <input
              id="identifier"
              className="fld"
              autoComplete="username"
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              placeholder="0712 345 678"
              required
            />
          </div>

          <div>
            <label htmlFor="password" className="lbl">
              PASSWORD
            </label>
            <div style={{ position: 'relative' }}>
              <input
                id="password"
                className="fld"
                type={showPw ? 'text' : 'password'}
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                style={{ paddingRight: 48 }}
                required
              />
              <button
                type="button"
                aria-label={showPw ? 'Hide password' : 'Show password'}
                onClick={() => setShowPw((v) => !v)}
                style={{
                  position: 'absolute',
                  top: 5,
                  right: 5,
                  width: 36,
                  height: 36,
                  borderRadius: 9,
                  background: 'transparent',
                  border: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer',
                  color: '#8e98ae',
                }}
              >
                <Icon name="eye" size={16} />
              </button>
            </div>
          </div>
        </div>

        {error && (
          <div
            role="alert"
            style={{
              marginTop: 14,
              padding: '11px 13px',
              borderRadius: 12,
              background: 'rgba(244,143,190,0.09)',
              border: '1px solid rgba(244,143,190,0.3)',
              fontSize: 12,
              lineHeight: 1.5,
              color: '#f8c3dc',
            }}
          >
            {error}
          </div>
        )}

        <div style={{ marginTop: 'auto', padding: '20px 0 24px' }}>
          <button type="submit" className="btn-primary" disabled={!canSubmit} style={{ width: '100%', fontSize: 15 }}>
            {busy ? 'Signing in…' : 'Log In'}
          </button>
          <div style={{ textAlign: 'center', fontSize: 11, color: '#7e889f', marginTop: 12 }}>
            New here?{' '}
            <Link href="/register" style={{ color: '#a9b2ff', fontWeight: 700 }}>
              Create an account
            </Link>
          </div>
        </div>
      </form>
    </main>
  );
}
