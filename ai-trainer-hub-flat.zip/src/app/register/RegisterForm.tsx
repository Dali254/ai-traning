'use client';

import { useState, useMemo } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import Icon from '@/components/Icon';
import { money } from '@/lib/fmt';

/**
 * Four fields: name, phone, email, password.
 * Country is derived from the phone prefix; referral comes from ?ref=.
 * No confirm-password — a show/hide toggle plus a strength meter catches
 * typos better and removes a field (PROJECT.md decisions log).
 */

const COUNTRY_NAMES: Record<string, string> = {
  '254': 'Kenya',
  '255': 'Tanzania',
  '256': 'Uganda',
  '250': 'Rwanda',
  '260': 'Zambia',
  '265': 'Malawi',
  '251': 'Ethiopia',
  '243': 'DR Congo',
  '258': 'Mozambique',
  '267': 'Botswana',
  '234': 'Nigeria',
  '233': 'Ghana',
  '27': 'South Africa',
};

function strength(pw: string): { score: 0 | 1 | 2 | 3 | 4; label: string; color: string } {
  if (!pw) return { score: 0, label: '', color: 'transparent' };
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) score++;
  if (/\d/.test(pw) || /[^A-Za-z0-9]/.test(pw)) score++;
  const clamped = Math.min(4, score) as 0 | 1 | 2 | 3 | 4;
  const map = {
    0: { label: 'TOO SHORT', color: 'var(--danger)' },
    1: { label: 'WEAK', color: 'var(--danger)' },
    2: { label: 'FAIR', color: 'var(--warn)' },
    3: { label: 'GOOD', color: '#4fcfae' },
    4: { label: 'STRONG', color: '#4fcfae' },
  } as const;
  return { score: clamped, ...map[clamped] };
}

export default function RegisterForm({
  referral,
  paidMembership,
  membershipFee,
  currency,
}: {
  referral: string;
  paidMembership: boolean;
  membershipFee: number;
  currency: string;
}) {
  const router = useRouter();
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const pw = useMemo(() => strength(password), [password]);

  // Detected country, shown as a chip rather than asked for.
  const country = useMemo(() => {
    const digits = phone.replace(/\D/g, '');
    if (digits.startsWith('0') || digits.length <= 9) return 'Kenya';
    for (const len of [3, 2]) {
      const hit = COUNTRY_NAMES[digits.slice(0, len)];
      if (hit) return hit;
    }
    return null;
  }, [phone]);

  const canSubmit =
    fullName.trim().length >= 2 &&
    phone.replace(/\D/g, '').length >= 9 &&
    /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) &&
    password.length >= 8 &&
    !busy;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!canSubmit) return;
    setBusy(true);
    setError('');

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          full_name: fullName.trim(),
          phone: phone.trim(),
          email: email.trim(),
          password,
          ref: referral || undefined,
        }),
      });
      const data = (await res.json()) as { error?: string; next?: string };
      if (!res.ok) {
        setError(data.error ?? 'Could not create your account');
        setBusy(false);
        return;
      }
      router.push(data.next ?? '/dashboard');
    } catch {
      setError('Network error. Check your connection and try again.');
      setBusy(false);
    }
  }

  return (
    <main
      style={{
        position: 'relative',
        minHeight: '100dvh',
        display: 'flex',
        flexDirection: 'column',
        maxWidth: 520,
        margin: '0 auto',
      }}
    >
      <div
        className="glow"
        style={{
          top: -160,
          left: -110,
          width: 420,
          height: 420,
          background: 'radial-gradient(circle, rgba(94,92,255,0.26) 0%, rgba(94,92,255,0) 68%)',
        }}
      />

      <header style={{ position: 'relative', zIndex: 2, display: 'flex', alignItems: 'center', gap: 12, padding: '14px 18px 12px' }}>
        <Link
          href="/"
          aria-label="Go back"
          style={{
            width: 36,
            height: 36,
            borderRadius: 12,
            border: '1px solid var(--border-strong)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#c6cbe0',
          }}
        >
          <Icon name="arrow-left" size={15} strokeWidth={2.2} />
        </Link>
        <span style={{ fontSize: 13, fontWeight: 700, color: '#8e98ae', letterSpacing: '-0.012em' }}>
          Join AI Trainer Hub
        </span>
      </header>

      <form
        onSubmit={submit}
        style={{ position: 'relative', zIndex: 1, flex: 1, padding: '6px 18px 0', display: 'flex', flexDirection: 'column' }}
      >
        <h1 style={{ margin: 0, fontSize: 27, fontWeight: 900, letterSpacing: '-0.034em', lineHeight: 1.12 }}>
          Create your
          <br />
          free account
        </h1>
        <p style={{ margin: '9px 0 0', fontSize: 12.5, lineHeight: 1.5, color: '#8e98ae' }}>
          {paidMembership
            ? `Four details, then a one-time ${money(membershipFee, currency)} M-Pesa payment.`
            : 'Four details and you are in. No card needed.'}
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 11, marginTop: 20 }}>
          <div>
            <label htmlFor="name" className="lbl">
              FULL NAME
            </label>
            <input
              id="name"
              className="fld"
              autoComplete="name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Amara Kimani"
              required
            />
          </div>

          <div>
            <label htmlFor="phone" className="lbl">
              M&#8209;PESA PHONE NUMBER
            </label>
            <div style={{ display: 'flex', gap: 7 }}>
              <div
                className="fld num"
                style={{
                  width: 92,
                  flexShrink: 0,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 6,
                  fontWeight: 750,
                }}
              >
                <span style={{ color: '#8e98ae', display: 'flex' }}>
                  <Icon name="globe" size={13} strokeWidth={1.9} />
                </span>
                +254
              </div>
              <input
                id="phone"
                className="fld num"
                type="tel"
                inputMode="tel"
                autoComplete="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="712 345 678"
                required
              />
            </div>
          </div>

          <div>
            <label htmlFor="email" className="lbl">
              EMAIL ADDRESS
            </label>
            <input
              id="email"
              className="fld"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              required
            />
          </div>

          <div>
            <label htmlFor="password" className="lbl">
              PASSWORD
            </label>
            <div style={{ position: 'relative' }}>
              <input
                id="password"
                className="fld"
                type={showPw ? 'text' : 'password'}
                autoComplete="new-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                style={{ paddingRight: 48 }}
                minLength={8}
                required
              />
              <button
                type="button"
                aria-label={showPw ? 'Hide password' : 'Show password'}
                onClick={() => setShowPw((v) => !v)}
                style={{
                  position: 'absolute',
                  top: 5,
                  right: 5,
                  width: 36,
                  height: 36,
                  borderRadius: 9,
                  background: 'transparent',
                  border: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer',
                  color: '#8e98ae',
                }}
              >
                <Icon name="eye" size={16} />
              </button>
            </div>
            {password.length > 0 && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 6 }}>
                {[1, 2, 3, 4].map((i) => (
                  <div
                    key={i}
                    style={{
                      flex: 1,
                      height: 3,
                      borderRadius: 99,
                      background: i <= pw.score ? pw.color : 'rgba(255,255,255,0.1)',
                    }}
                  />
                ))}
                <span
                  style={{
                    fontSize: 9.5,
                    fontWeight: 800,
                    color: pw.color,
                    marginLeft: 4,
                    letterSpacing: '0.04em',
                  }}
                >
                  {pw.label}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* auto-detected, not asked for */}
        {(country || referral) && (
          <div style={{ display: 'flex', gap: 7, marginTop: 14 }}>
            {country && (
              <div style={detectedChip}>
                <span style={{ color: '#4fcfae', flexShrink: 0, display: 'flex' }}>
                  <Icon name="check" size={14} strokeWidth={2.3} />
                </span>
                <div style={{ minWidth: 0 }}>
                  <div style={chipLabel}>COUNTRY</div>
                  <div style={chipValue}>{country}</div>
                </div>
              </div>
            )}
            {referral && (
              <div style={detectedChip}>
                <span style={{ color: '#4fcfae', flexShrink: 0, display: 'flex' }}>
                  <Icon name="check" size={14} strokeWidth={2.3} />
                </span>
                <div style={{ minWidth: 0 }}>
                  <div style={chipLabel}>REFERRED BY</div>
                  <div className="num" style={chipValue}>
                    {referral}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {error && (
          <div
            role="alert"
            style={{
              marginTop: 14,
              padding: '11px 13px',
              borderRadius: 12,
              background: 'rgba(244,143,190,0.09)',
              border: '1px solid rgba(244,143,190,0.3)',
              fontSize: 12,
              lineHeight: 1.5,
              color: '#f8c3dc',
            }}
          >
            {error}
          </div>
        )}

        <p style={{ fontSize: 10.5, lineHeight: 1.5, color: 'var(--text-faint)', margin: '14px 0 0' }}>
          By continuing you agree to the{' '}
          <Link href="/terms" style={{ color: '#a9b2ff', fontWeight: 700 }}>
            Terms
          </Link>{' '}
          and{' '}
          <Link href="/privacy" style={{ color: '#a9b2ff', fontWeight: 700 }}>
            Privacy Policy
          </Link>
          , and confirm you are 18 or older.
        </p>

        <div style={{ marginTop: 'auto', padding: '16px 0 24px' }}>
          <button type="submit" className="btn-primary" disabled={!canSubmit} style={{ width: '100%', fontSize: 15 }}>
            {busy ? 'Creating account…' : 'Create Account'}
          </button>
          <div style={{ textAlign: 'center', fontSize: 11, color: '#7e889f', marginTop: 12 }}>
            Already a member?{' '}
            <Link href="/login" style={{ color: '#a9b2ff', fontWeight: 700 }}>
              Log in
            </Link>
          </div>
        </div>
      </form>
    </main>
  );
}

const detectedChip: React.CSSProperties = {
  flex: 1,
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  padding: '10px 12px',
  borderRadius: 12,
  background: 'rgba(0,224,180,0.055)',
  border: '1px solid rgba(0,224,180,0.2)',
};

const chipLabel: React.CSSProperties = {
  fontSize: 8.5,
  fontWeight: 800,
  color: '#4fcfae',
  letterSpacing: '0.08em',
};

const chipValue: React.CSSProperties = {
  fontSize: 11.5,
  fontWeight: 750,
  color: '#d8dcf0',
  marginTop: 1,
};
