import { NextResponse } from 'next/server';
import { transaction, queryOne } from '@/lib/db';
import { hashPassword, createSession } from '@/lib/session';
import { normalisePhone, MpesaError } from '@/lib/mpesa';
import { getBool, getNumber } from '@/lib/settings';
import { post } from '@/lib/wallet';

export const runtime = 'nodejs';

/**
 * Registration — four fields only (PROJECT.md decisions log):
 *   full_name, phone, email, password
 *
 * Country is derived from the phone's country code.
 * Referral comes from the invite link (?ref=CODE), not a field the member types.
 */

const COUNTRY_BY_PREFIX: Record<string, string> = {
  '254': 'KE',
  '255': 'TZ',
  '256': 'UG',
  '250': 'RW',
  '260': 'ZM',
  '265': 'MW',
  '251': 'ET',
  '243': 'CD',
  '258': 'MZ',
  '267': 'BW',
  '234': 'NG',
  '233': 'GH',
  '27': 'ZA',
};

function countryFromPhone(msisdn: string): string {
  for (const len of [3, 2]) {
    const hit = COUNTRY_BY_PREFIX[msisdn.slice(0, len)];
    if (hit) return hit;
  }
  return 'OTH';
}

function makeReferralCode(): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no look-alikes
  let out = '';
  for (let i = 0; i < 6; i++) {
    out += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  return `TRN-${out}`;
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => null)) as {
    full_name?: string;
    phone?: string;
    email?: string;
    password?: string;
    ref?: string;
  } | null;

  if (!body) return NextResponse.json({ error: 'Invalid request body' }, { status: 400 });

  const fullName = (body.full_name ?? '').trim();
  const email = (body.email ?? '').trim().toLowerCase();
  const password = body.password ?? '';
  const refCode = (body.ref ?? '').trim().toUpperCase();

  // ── Validation ────────────────────────────────────────────────────────
  if (fullName.length < 2 || fullName.length > 120) {
    return NextResponse.json({ error: 'Enter your full name' }, { status: 400 });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
    return NextResponse.json({ error: 'Enter a valid email address' }, { status: 400 });
  }
  if (password.length < 8) {
    return NextResponse.json({ error: 'Password must be at least 8 characters' }, { status: 400 });
  }
  if (password.length > 200) {
    return NextResponse.json({ error: 'Password is too long' }, { status: 400 });
  }

  let phone: string;
  try {
    phone = normalisePhone(body.phone ?? '');
  } catch (err) {
    const message = err instanceof MpesaError ? err.message : 'Enter a valid phone number';
    return NextResponse.json({ error: message }, { status: 400 });
  }

  // ── Uniqueness, checked up front for a clean message ─────────────────
  const clash = await queryOne<{ phone: string; email: string }>(
    'SELECT phone, email FROM users WHERE phone = $1 OR email = $2 LIMIT 1',
    [phone, email]
  );
  if (clash) {
    const which = clash.phone === phone ? 'phone number' : 'email address';
    return NextResponse.json(
      { error: `That ${which} is already registered. Try logging in instead.` },
      { status: 409 }
    );
  }

  const country = countryFromPhone(phone);
  const passwordHash = await hashPassword(password);
  const paidMembership = await getBool('paid_membership', false);
  const referralsOn = await getBool('referrals_enabled', true);
  const signupBonus = await getNumber('bonus_first_task_amount', 0);

  let userId: number;
  try {
    userId = await transaction(async (c) => {
      // Resolve the referrer from the invite code, if referrals are on.
      let referredBy: number | null = null;
      if (referralsOn && refCode) {
        const ref = await c.query<{ id: number }>(
          `SELECT id FROM users WHERE referral_code = $1 AND account_status = 'active'`,
          [refCode]
        );
        referredBy = ref.rows[0]?.id ?? null;
      }

      // Starting level is the lowest configured one.
      const lvl = await c.query<{ id: number }>(
        'SELECT id FROM member_levels ORDER BY position ASC LIMIT 1'
      );
      const levelId = lvl.rows[0]?.id ?? null;

      // Referral codes are unique; retry on the astronomically unlikely clash.
      let code = makeReferralCode();
      for (let i = 0; i < 5; i++) {
        const taken = await c.query('SELECT 1 FROM users WHERE referral_code = $1', [code]);
        if (taken.rowCount === 0) break;
        code = makeReferralCode();
      }

      const inserted = await c.query<{ id: number }>(
        `INSERT INTO users
           (full_name, phone, email, password_hash, country, level_id,
            membership_status, referral_code, referred_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
         RETURNING id`,
        [
          fullName,
          phone,
          email,
          passwordHash,
          country,
          levelId,
          paidMembership ? 'pending_payment' : 'free',
          code,
          referredBy,
        ]
      );
      const newId = inserted.rows[0].id;

      // Wallet is created with the account — never lazily.
      await c.query('INSERT INTO wallets (user_id) VALUES ($1)', [newId]);

      if (referredBy) {
        await c.query(
          `INSERT INTO referrals (referrer_id, referred_id) VALUES ($1, $2)
           ON CONFLICT (referred_id) DO NOTHING`,
          [referredBy, newId]
        );
        await c.query(
          `INSERT INTO notifications (user_id, type, title, body)
           VALUES ($1, 'referral', 'New referral joined',
                   $2 || ' signed up with your referral link.')`,
          [referredBy, fullName]
        );
      }

      // Welcome bonus, if admin has one configured.
      if (signupBonus > 0 && (await getBool('bonus_first_task', false))) {
        await post(
          {
            userId: newId,
            type: 'first_task_bonus',
            amount: signupBonus,
            description: 'Welcome bonus',
            reference: `signup-${newId}`,
            bucket: 'available',
          },
          c
        );
      }

      await c.query(
        `INSERT INTO notifications (user_id, type, title, body)
         VALUES ($1, 'system', 'Welcome to AI Trainer Hub',
                 'Your account is ready. Open Tasks to see today''s allocation.')`,
        [newId]
      );

      return newId;
    });
  } catch (err) {
    console.error('[auth:register]', err);
    return NextResponse.json({ error: 'Could not create your account. Try again.' }, { status: 500 });
  }

  await createSession(userId);

  return NextResponse.json({
    success: true,
    userId,
    country,
    next: paidMembership ? '/pay' : '/dashboard',
  });
}
