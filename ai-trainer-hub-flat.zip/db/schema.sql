-- ═══════════════════════════════════════════════════════════════════════
-- AI Trainer Hub — Postgres schema
-- Run once:  psql "$DATABASE_URL" -f db/schema.sql
-- Then:      psql "$DATABASE_URL" -f db/seed.sql
--
-- Money is NUMERIC(14,2) throughout — never float.
-- wallet_transactions is APPEND-ONLY. See PROJECT.md §5.
-- ═══════════════════════════════════════════════════════════════════════

-- ─── Settings: every tunable value. Nothing is hardcoded in app code. ───
CREATE TABLE IF NOT EXISTS settings (
  key         TEXT PRIMARY KEY,
  value       TEXT NOT NULL,
  value_type  TEXT NOT NULL DEFAULT 'string'
                CHECK (value_type IN ('string','number','boolean','json')),
  category    TEXT NOT NULL DEFAULT 'general',
  label       TEXT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── Member levels ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS member_levels (
  id                 SERIAL PRIMARY KEY,
  position           INT  NOT NULL UNIQUE,
  name               TEXT NOT NULL,
  required_points    INT  NOT NULL DEFAULT 0,
  required_tasks     INT  NOT NULL DEFAULT 0,
  required_accuracy  NUMERIC(5,2) NOT NULL DEFAULT 0,
  reward_multiplier  NUMERIC(5,2) NOT NULL DEFAULT 1.00,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── Difficulty levels: reward per task comes from here ──────────────────
CREATE TABLE IF NOT EXISTS difficulty_levels (
  id                SERIAL PRIMARY KEY,
  position          INT  NOT NULL UNIQUE,
  name              TEXT NOT NULL,
  description       TEXT,
  reward            NUMERIC(14,2) NOT NULL DEFAULT 0,
  bonus             NUMERIC(14,2) NOT NULL DEFAULT 0,
  reward_multiplier NUMERIC(5,2)  NOT NULL DEFAULT 1.00,
  min_member_level  INT NOT NULL DEFAULT 1,
  points_awarded    INT NOT NULL DEFAULT 10,
  active            BOOLEAN NOT NULL DEFAULT true,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── AI models shown on the site. Logos are admin-uploaded. ─────────────
CREATE TABLE IF NOT EXISTS ai_models (
  id          SERIAL PRIMARY KEY,
  slug        TEXT NOT NULL UNIQUE,
  name        TEXT NOT NULL,
  logo_path   TEXT,                    -- NULL → neutral SVG fallback mark
  accent      TEXT NOT NULL DEFAULT '#7C8CFF',
  sort_order  INT  NOT NULL DEFAULT 0,
  visible     BOOLEAN NOT NULL DEFAULT true,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── Users ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id                BIGSERIAL PRIMARY KEY,
  full_name         TEXT NOT NULL,
  phone             TEXT NOT NULL UNIQUE,      -- stored as 2547XXXXXXXX
  email             TEXT NOT NULL UNIQUE,
  password_hash     TEXT NOT NULL,
  country           TEXT NOT NULL DEFAULT 'KE',
  role              TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('member','admin')),

  membership_status TEXT NOT NULL DEFAULT 'free'
                      CHECK (membership_status IN ('free','paid','pending_payment','suspended')),
  account_status    TEXT NOT NULL DEFAULT 'active'
                      CHECK (account_status IN ('active','suspended')),

  level_id          INT REFERENCES member_levels(id),
  points            INT NOT NULL DEFAULT 0,

  tasks_completed   INT NOT NULL DEFAULT 0,
  tasks_rejected    INT NOT NULL DEFAULT 0,
  accuracy          NUMERIC(5,2) NOT NULL DEFAULT 0,
  streak_days       INT NOT NULL DEFAULT 0,
  last_task_date    DATE,

  referral_code     TEXT NOT NULL UNIQUE,
  referred_by       BIGINT REFERENCES users(id),

  hide_name         BOOLEAN NOT NULL DEFAULT false,  -- leaderboard privacy
  failed_logins     INT NOT NULL DEFAULT 0,
  locked_until      TIMESTAMPTZ,
  last_login_at     TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_users_phone    ON users(phone);
CREATE INDEX IF NOT EXISTS idx_users_referral ON users(referral_code);
CREATE INDEX IF NOT EXISTS idx_users_points   ON users(points DESC);

-- ─── Wallet: one per user, balances are a cache of the ledger ───────────
CREATE TABLE IF NOT EXISTS wallets (
  id                BIGSERIAL PRIMARY KEY,
  user_id           BIGINT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  available_balance NUMERIC(14,2) NOT NULL DEFAULT 0,
  pending_balance   NUMERIC(14,2) NOT NULL DEFAULT 0,
  total_earned      NUMERIC(14,2) NOT NULL DEFAULT 0,
  total_withdrawn   NUMERIC(14,2) NOT NULL DEFAULT 0,
  total_bonuses     NUMERIC(14,2) NOT NULL DEFAULT 0,
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT wallet_non_negative CHECK (available_balance >= 0 AND pending_balance >= 0)
);

-- ─── Ledger. APPEND-ONLY: never UPDATE or DELETE a row here. ───────────
CREATE TABLE IF NOT EXISTS wallet_transactions (
  id             BIGSERIAL PRIMARY KEY,
  user_id        BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  wallet_id      BIGINT NOT NULL REFERENCES wallets(id) ON DELETE CASCADE,
  type           TEXT NOT NULL CHECK (type IN (
                   'task_reward','difficulty_bonus','performance_bonus','daily_bonus',
                   'weekly_bonus','first_task_bonus','login_bonus','streak_bonus',
                   'level_up_bonus','accuracy_bonus','leaderboard_bonus',
                   'referral_commission','withdrawal','withdrawal_fee',
                   'withdrawal_reversal','admin_credit','admin_debit',
                   'pending_release','pending_hold')),
  direction      TEXT NOT NULL CHECK (direction IN ('credit','debit')),
  amount         NUMERIC(14,2) NOT NULL CHECK (amount >= 0),
  balance_before NUMERIC(14,2) NOT NULL,
  balance_after  NUMERIC(14,2) NOT NULL,
  description    TEXT NOT NULL,
  reference      TEXT,                     -- submission id, withdrawal id, mpesa ref...
  status         TEXT NOT NULL DEFAULT 'completed'
                   CHECK (status IN ('pending','completed','reversed')),
  created_by     BIGINT REFERENCES users(id),   -- admin, when manual
  reason         TEXT,                          -- REQUIRED for admin_credit/admin_debit
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_wtx_user ON wallet_transactions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_wtx_ref  ON wallet_transactions(reference);

-- Enforce append-only at the database level.
CREATE OR REPLACE FUNCTION ledger_is_immutable() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'wallet_transactions is append-only: use a reversing entry instead';
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_ledger_no_update ON wallet_transactions;
CREATE TRIGGER trg_ledger_no_update
  BEFORE UPDATE OR DELETE ON wallet_transactions
  FOR EACH ROW EXECUTE FUNCTION ledger_is_immutable();

-- ─── Tasks: the pool. Generated in batches, recycled after a window. ────
CREATE TABLE IF NOT EXISTS task_batches (
  id          BIGSERIAL PRIMARY KEY,
  source      TEXT NOT NULL DEFAULT 'claude' CHECK (source IN ('claude','manual','import')),
  model_used  TEXT,
  requested   INT NOT NULL DEFAULT 0,
  generated   INT NOT NULL DEFAULT 0,
  status      TEXT NOT NULL DEFAULT 'review' CHECK (status IN ('review','live','discarded')),
  cost_usd    NUMERIC(10,4),
  params      JSONB,
  created_by  BIGINT REFERENCES users(id),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS tasks (
  id             BIGSERIAL PRIMARY KEY,
  batch_id       BIGINT REFERENCES task_batches(id) ON DELETE SET NULL,
  title          TEXT NOT NULL,
  description    TEXT,
  instructions   TEXT,
  task_type      TEXT NOT NULL,          -- response_comparison, prompt_evaluation, ...
  ai_model_id    INT REFERENCES ai_models(id),
  difficulty_id  INT NOT NULL REFERENCES difficulty_levels(id),

  payload        JSONB NOT NULL,         -- prompt, options, etc. Shape varies by task_type
  expected_answer JSONB,                 -- gold answer; NULL = unscored
  is_audit       BOOLEAN NOT NULL DEFAULT false,  -- human-verified; accuracy scored on these

  reward_override NUMERIC(14,2),         -- NULL → take reward from difficulty level
  est_minutes    INT NOT NULL DEFAULT 3,
  max_attempts   INT NOT NULL DEFAULT 1,

  status         TEXT NOT NULL DEFAULT 'review'
                   CHECK (status IN ('review','live','paused','archived')),
  times_served   INT NOT NULL DEFAULT 0,
  retired_at     TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_tasks_live ON tasks(status, difficulty_id)
  WHERE status = 'live';
CREATE INDEX IF NOT EXISTS idx_tasks_batch ON tasks(batch_id);

-- ─── Daily allocation. One row = this task was given to this member. ───
-- The UNIQUE constraint is what guarantees "never the same task twice".
CREATE TABLE IF NOT EXISTS task_assignments (
  id           BIGSERIAL PRIMARY KEY,
  user_id      BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  task_id      BIGINT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  assigned_for DATE   NOT NULL,          -- the EAT day this belongs to
  status       TEXT   NOT NULL DEFAULT 'assigned'
                 CHECK (status IN ('assigned','submitted','expired','skipped')),
  assigned_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, task_id)
);
CREATE INDEX IF NOT EXISTS idx_assign_today ON task_assignments(user_id, assigned_for);

-- ─── Submissions ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS submissions (
  id              BIGSERIAL PRIMARY KEY,
  user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  task_id         BIGINT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  assignment_id   BIGINT REFERENCES task_assignments(id) ON DELETE SET NULL,
  answer          JSONB NOT NULL,
  confidence      INT CHECK (confidence BETWEEN 1 AND 5),
  seconds_taken   INT,
  score           NUMERIC(5,2),          -- NULL until scored
  passed          BOOLEAN,
  status          TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending','approved','rejected')),
  reward_paid     NUMERIC(14,2) NOT NULL DEFAULT 0,
  points_paid     INT NOT NULL DEFAULT 0,
  reviewed_by     BIGINT REFERENCES users(id),
  reviewed_at     TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, task_id)
);
CREATE INDEX IF NOT EXISTS idx_sub_user ON submissions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sub_status ON submissions(status);

-- ─── M-Pesa transactions (membership payments, and B2C payouts) ────────
CREATE TABLE IF NOT EXISTS mpesa_transactions (
  id               BIGSERIAL PRIMARY KEY,
  transaction_id   TEXT UNIQUE,          -- PesaFlux PFX... — unique = idempotent webhook
  user_id          BIGINT REFERENCES users(id) ON DELETE SET NULL,
  direction        TEXT NOT NULL DEFAULT 'in' CHECK (direction IN ('in','out')),
  purpose          TEXT NOT NULL CHECK (purpose IN ('membership','topup','withdrawal')),
  phone            TEXT NOT NULL,
  amount           NUMERIC(14,2) NOT NULL,
  reference        TEXT,
  status           TEXT NOT NULL DEFAULT 'pending'
                     CHECK (status IN ('pending','success','failed','expired')),
  mpesa_receipt    TEXT,
  result_desc      TEXT,
  raw_request      JSONB,
  raw_callback     JSONB,
  transaction_date TIMESTAMPTZ,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_mpesa_user ON mpesa_transactions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_mpesa_ref  ON mpesa_transactions(reference);

-- ─── Payout runs: the daily/weekly/monthly settlement batch ────────────
CREATE TABLE IF NOT EXISTS payout_runs (
  id             BIGSERIAL PRIMARY KEY,
  run_for        DATE NOT NULL,
  cycle          TEXT NOT NULL CHECK (cycle IN ('daily','weekly','monthly')),
  status         TEXT NOT NULL DEFAULT 'pending'
                   CHECK (status IN ('pending','processing','completed','failed')),
  withdrawal_count INT NOT NULL DEFAULT 0,
  total_amount   NUMERIC(14,2) NOT NULL DEFAULT 0,
  started_at     TIMESTAMPTZ,
  completed_at   TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── Withdrawals: queued, then settled by a payout run ─────────────────
CREATE TABLE IF NOT EXISTS withdrawals (
  id             BIGSERIAL PRIMARY KEY,
  user_id        BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  payout_run_id  BIGINT REFERENCES payout_runs(id) ON DELETE SET NULL,
  phone          TEXT NOT NULL,
  amount         NUMERIC(14,2) NOT NULL CHECK (amount > 0),
  fee            NUMERIC(14,2) NOT NULL DEFAULT 0,
  net_amount     NUMERIC(14,2) NOT NULL,
  status         TEXT NOT NULL DEFAULT 'pending'
                   CHECK (status IN ('pending','processing','paid','rejected','cancelled')),
  mpesa_receipt  TEXT,
  mpesa_tx_id    BIGINT REFERENCES mpesa_transactions(id) ON DELETE SET NULL,
  reject_reason  TEXT,
  approved_by    BIGINT REFERENCES users(id),
  requested_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  settled_at     TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_wd_user   ON withdrawals(user_id, requested_at DESC);
CREATE INDEX IF NOT EXISTS idx_wd_status ON withdrawals(status);

-- ─── Referrals ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS referrals (
  id            BIGSERIAL PRIMARY KEY,
  referrer_id   BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  referred_id   BIGINT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  total_earned  NUMERIC(14,2) NOT NULL DEFAULT 0,
  active        BOOLEAN NOT NULL DEFAULT true,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_ref_referrer ON referrals(referrer_id);

-- ─── Notifications ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
  id         BIGSERIAL PRIMARY KEY,
  user_id    BIGINT REFERENCES users(id) ON DELETE CASCADE,  -- NULL = broadcast
  level_id   INT REFERENCES member_levels(id),               -- target a level
  type       TEXT NOT NULL,
  title      TEXT NOT NULL,
  body       TEXT,
  read_at    TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, created_at DESC);

-- ─── Admin audit log ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_logs (
  id         BIGSERIAL PRIMARY KEY,
  admin_id   BIGINT REFERENCES users(id) ON DELETE SET NULL,
  action     TEXT NOT NULL,
  target     TEXT,
  prev_value TEXT,
  new_value  TEXT,
  reason     TEXT,
  ip_address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_logs(created_at DESC);

-- ─── Rate limiting (auth attempts, submissions) ────────────────────────
CREATE TABLE IF NOT EXISTS rate_limits (
  id          BIGSERIAL PRIMARY KEY,
  bucket      TEXT NOT NULL,          -- e.g. 'login:102.x.x.x'
  hits        INT  NOT NULL DEFAULT 1,
  window_start TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (bucket)
);
