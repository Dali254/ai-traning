import { query, transaction } from './db';
import { getNumber } from './settings';
import { eatToday } from './fmt';

/**
 * Daily task rotation.
 *
 * Admin generates a large pool; each member is handed N tasks per day
 * (`tasks_per_day`, default 2). A member never receives the same task twice
 * inside the recycle window (`recycle_days`, default 30) — guaranteed by the
 * UNIQUE (user_id, task_id) constraint on task_assignments plus the NOT EXISTS
 * filter below.
 *
 * Assignment is lazy: the first time a member opens Tasks on a given day,
 * their set is created. The nightly cron pre-warms it for active members so
 * the first load of the day is fast.
 */

export type AssignedTask = {
  assignment_id: number;
  task_id: number;
  title: string;
  description: string | null;
  instructions: string | null;
  task_type: string;
  payload: unknown;
  est_minutes: number;
  status: 'assigned' | 'submitted' | 'expired' | 'skipped';
  difficulty_name: string;
  difficulty_position: number;
  reward: string;
  model_name: string | null;
  model_slug: string | null;
  model_logo: string | null;
  model_accent: string | null;
};

/**
 * Ensure the member has today's allocation, then return it.
 * Safe to call repeatedly — it tops up to the quota and never duplicates.
 */
export async function getTodaysTasks(userId: number, memberLevel: number): Promise<AssignedTask[]> {
  const day = eatToday();
  const perDay = Math.max(1, await getNumber('tasks_per_day', 2));
  const recycleDays = Math.max(0, await getNumber('recycle_days', 30));

  const existing = await countAssigned(userId, day);
  if (existing < perDay) {
    await assignFor(userId, day, perDay - existing, memberLevel, recycleDays);
  }

  return listAssigned(userId, day);
}

async function countAssigned(userId: number, day: string): Promise<number> {
  const rows = await query<{ n: string }>(
    `SELECT COUNT(*)::text AS n FROM task_assignments
      WHERE user_id = $1 AND assigned_for = $2`,
    [userId, day]
  );
  return Number(rows[0]?.n ?? 0);
}

/**
 * Pick `want` live tasks this member hasn't seen inside the recycle window,
 * at or below their level, and claim them.
 *
 * Concurrency: two parallel requests could both pick the same task. The
 * UNIQUE (user_id, task_id) constraint turns the loser into a no-op via
 * ON CONFLICT DO NOTHING, so we just retry the shortfall once.
 */
async function assignFor(
  userId: number,
  day: string,
  want: number,
  memberLevel: number,
  recycleDays: number
): Promise<void> {
  for (let attempt = 0; attempt < 2 && want > 0; attempt++) {
    const inserted = await transaction(async (c) => {
      const res = await c.query<{ task_id: number }>(
        `INSERT INTO task_assignments (user_id, task_id, assigned_for)
         SELECT $1, t.id, $2
           FROM tasks t
           JOIN difficulty_levels d ON d.id = t.difficulty_id
          WHERE t.status = 'live'
            AND d.active = true
            AND d.min_member_level <= $3
            AND t.retired_at IS NULL
            AND NOT EXISTS (
              SELECT 1 FROM task_assignments a
               WHERE a.user_id = $1
                 AND a.task_id = t.id
                 AND ($5 = 0 OR a.assigned_at > now() - ($5 || ' days')::interval)
            )
          ORDER BY t.times_served ASC, random()
          LIMIT $4
         ON CONFLICT (user_id, task_id) DO NOTHING
         RETURNING task_id`,
        [userId, day, memberLevel, want, recycleDays]
      );

      if (res.rows.length > 0) {
        await c.query(
          `UPDATE tasks SET times_served = times_served + 1
            WHERE id = ANY($1::bigint[])`,
          [res.rows.map((r) => r.task_id)]
        );
      }
      return res.rows.length;
    });

    want -= inserted;
    if (inserted === 0) break; // pool exhausted for this member
  }
}

async function listAssigned(userId: number, day: string): Promise<AssignedTask[]> {
  return query<AssignedTask>(
    `SELECT a.id            AS assignment_id,
            t.id            AS task_id,
            t.title, t.description, t.instructions, t.task_type,
            t.payload, t.est_minutes,
            a.status,
            d.name          AS difficulty_name,
            d.position      AS difficulty_position,
            COALESCE(t.reward_override, d.reward) AS reward,
            m.name          AS model_name,
            m.slug          AS model_slug,
            m.logo_path     AS model_logo,
            m.accent        AS model_accent
       FROM task_assignments a
       JOIN tasks t             ON t.id = a.task_id
       JOIN difficulty_levels d ON d.id = t.difficulty_id
       LEFT JOIN ai_models m    ON m.id = t.ai_model_id
      WHERE a.user_id = $1 AND a.assigned_for = $2
      ORDER BY (a.status = 'submitted'), d.position DESC, a.id`,
    [userId, day]
  );
}

/** How much the member could still earn today. */
export async function todaysPotential(userId: number): Promise<{ total: number; earned: number }> {
  const day = eatToday();
  const rows = await query<{ pending: string; earned: string }>(
    `SELECT
       COALESCE(SUM(CASE WHEN a.status = 'assigned'
                    THEN COALESCE(t.reward_override, d.reward) ELSE 0 END), 0)::text AS pending,
       COALESCE(SUM(CASE WHEN a.status = 'submitted'
                    THEN COALESCE(s.reward_paid, 0) ELSE 0 END), 0)::text AS earned
       FROM task_assignments a
       JOIN tasks t             ON t.id = a.task_id
       JOIN difficulty_levels d ON d.id = t.difficulty_id
       LEFT JOIN submissions s  ON s.assignment_id = a.id
      WHERE a.user_id = $1 AND a.assigned_for = $2`,
    [userId, day]
  );
  return {
    total: Number(rows[0]?.pending ?? 0),
    earned: Number(rows[0]?.earned ?? 0),
  };
}

/** Pool stats for the rotation panel on the Tasks screen. */
export async function poolStats(userId: number) {
  const rows = await query<{ pool: string; seen: string; recycle: string }>(
    `SELECT
       (SELECT COUNT(*)::text FROM tasks WHERE status = 'live' AND retired_at IS NULL) AS pool,
       (SELECT COUNT(*)::text FROM task_assignments WHERE user_id = $1)                AS seen,
       (SELECT value FROM settings WHERE key = 'recycle_days')                         AS recycle`,
    [userId]
  );
  return {
    pool: Number(rows[0]?.pool ?? 0),
    seen: Number(rows[0]?.seen ?? 0),
    recycleDays: Number(rows[0]?.recycle ?? 30),
  };
}

/**
 * The moment the next allocation unlocks: the configured reset time, in EAT,
 * on the next day. Returned as a real UTC Date so the client can count down.
 */
export async function nextResetAt(now: Date = new Date()): Promise<Date> {
  const hhmm = (await query<{ value: string }>(
    `SELECT value FROM settings WHERE key = 'daily_reset_time'`
  ))[0]?.value ?? '00:00';

  const [h, m] = hhmm.split(':').map((v) => Number(v) || 0);

  // Build tomorrow's reset instant in EAT, expressed in UTC.
  const eat = new Date(now.getTime() + 3 * 60 * 60 * 1000);
  const y = eat.getUTCFullYear();
  const mo = eat.getUTCMonth();
  const d = eat.getUTCDate();

  let resetUtcMs = Date.UTC(y, mo, d, h, m) - 3 * 60 * 60 * 1000;
  if (resetUtcMs <= now.getTime()) resetUtcMs += 24 * 60 * 60 * 1000;

  return new Date(resetUtcMs);
}

/**
 * Pre-warm tomorrow's allocation for members who were active recently.
 * Called by /api/cron/rotate.
 */
export async function rotateAll(): Promise<{ members: number; assigned: number }> {
  const day = eatToday();
  const perDay = Math.max(1, await getNumber('tasks_per_day', 2));
  const recycleDays = Math.max(0, await getNumber('recycle_days', 30));

  const members = await query<{ id: number; position: number }>(
    `SELECT u.id, COALESCE(l.position, 1) AS position
       FROM users u
       LEFT JOIN member_levels l ON l.id = u.level_id
      WHERE u.account_status = 'active'
        AND u.role = 'member'
        AND (u.last_login_at > now() - interval '14 days' OR u.created_at > now() - interval '7 days')`
  );

  let assigned = 0;
  for (const m of members) {
    const have = await countAssigned(m.id, day);
    if (have >= perDay) continue;
    const before = have;
    await assignFor(m.id, day, perDay - have, m.position, recycleDays);
    assigned += (await countAssigned(m.id, day)) - before;
  }

  return { members: members.length, assigned };
}
