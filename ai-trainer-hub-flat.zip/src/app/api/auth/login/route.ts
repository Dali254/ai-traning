import { NextResponse } from 'next/server';
import { query, queryOne } from '@/lib/db';
import { verifyPassword, createSession } from '@/lib/session';
import { getNumber } from '@/lib/settings';
import { isValidPhone, normalisePhone } from '@/lib/mpesa';

export const runtime = 'nodejs';

/**
 * Login by phone OR email. Failed attempts lock the account for a configured
 * window (`max_login_attempts`, `lockout_minutes`) to blunt credential stuffing.
 */
export async function POST(req: Request) {
  const body = (await req.json().catch(() => null)) as {
    identifier?: string;
    password?: string;
  } | null;

  if (!body?.identifier || !body?.password) {
    return NextResponse.json({ error: 'Enter your phone or email and password' }, { status: 400 });
  }

  const identifier = body.identifier.trim();
  const maxAttempts = await getNumber('max_login_attempts', 5);
  const lockoutMins = await getNumber('lockout_minutes', 15);

  // Look up by normalised phone when it parses as one, otherwise by email.
  const byPhone = isValidPhone(identifier);
  const lookupValue = byPhone ? normalisePhone(identifier) : identifier.toLowerCase();

  const user = await queryOne<{
    id: number;
    password_hash: string;
    role: string;
    account_status: string;
    membership_status: string;
    failed_logins: number;
    locked_until: string | null;
  }>(
    `SELECT id, password_hash, role, account_status, membership_status,
            failed_logins, locked_until
       FROM users
      WHERE ${byPhone ? 'phone' : 'email'} = $1`,
    [lookupValue]
  );

  // Same message either way — don't reveal which accounts exist.
  const genericError = NextResponse.json(
    { error: 'Those details do not match an account' },
    { status: 401 }
  );

  if (!user) return genericError;

  if (user.locked_until && new Date(user.locked_until) > new Date()) {
    const mins = Math.ceil((new Date(user.locked_until).getTime() - Date.now()) / 60_000);
    return NextResponse.json(
      { error: `Too many failed attempts. Try again in ${mins} minute${mins === 1 ? '' : 's'}.` },
      { status: 429 }
    );
  }

  if (user.account_status === 'suspended') {
    return NextResponse.json(
      { error: 'This account is suspended. Contact support.' },
      { status: 403 }
    );
  }

  const ok = await verifyPassword(body.password, user.password_hash);

  if (!ok) {
    const attempts = user.failed_logins + 1;
    const shouldLock = maxAttempts > 0 && attempts >= maxAttempts;
    await query(
      `UPDATE users
          SET failed_logins = $2,
              locked_until = CASE WHEN $3 THEN now() + ($4 || ' minutes')::interval ELSE NULL END
        WHERE id = $1`,
      [user.id, shouldLock ? 0 : attempts, shouldLock, lockoutMins]
    );
    if (shouldLock) {
      return NextResponse.json(
        { error: `Too many failed attempts. Try again in ${lockoutMins} minutes.` },
        { status: 429 }
      );
    }
    return genericError;
  }

  await query(
    `UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = now()
      WHERE id = $1`,
    [user.id]
  );

  await createSession(user.id);

  const next =
    user.role === 'admin'
      ? '/admin'
      : user.membership_status === 'pending_payment'
        ? '/pay'
        : '/dashboard';

  return NextResponse.json({ success: true, next });
}
