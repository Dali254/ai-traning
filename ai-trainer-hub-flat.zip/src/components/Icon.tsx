/**
 * Inline stroke SVG icon set. No emoji anywhere in this app (PROJECT.md §3).
 * Every icon inherits `currentColor` so it takes the surrounding text colour.
 */

type Props = {
  name: IconName;
  size?: number;
  className?: string;
  /** Set when the icon carries meaning on its own; otherwise it's decorative. */
  label?: string;
  strokeWidth?: number;
};

export type IconName =
  | 'home'
  | 'tasks'
  | 'money'
  | 'user'
  | 'chart'
  | 'wallet'
  | 'calendar'
  | 'clock'
  | 'check'
  | 'close'
  | 'arrow-right'
  | 'arrow-left'
  | 'arrow-up'
  | 'search'
  | 'filter'
  | 'bell'
  | 'lock'
  | 'star'
  | 'spark'
  | 'refresh'
  | 'eye'
  | 'upload'
  | 'trash'
  | 'image'
  | 'grid'
  | 'users'
  | 'settings'
  | 'trophy'
  | 'warning'
  | 'globe'
  | 'phone'
  | 'plus'
  | 'logout'
  | 'activity';

const PATHS: Record<IconName, React.ReactNode> = {
  home: <path d="M3 11l9-8 9 8M5 10v10h14V10" />,
  tasks: (
    <>
      <path d="M9 11l3 3L22 4" />
      <path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11" />
    </>
  ),
  money: <path d="M12 1v22M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6" />,
  user: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21v-1a8 8 0 0116 0v1" />
    </>
  ),
  chart: <path d="M18 20V10M12 20V4M6 20v-6" />,
  wallet: (
    <>
      <path d="M20 12V8H6a2 2 0 010-4h12v4" />
      <path d="M4 6v12a2 2 0 002 2h14v-4" />
      <path d="M18 12a2 2 0 000 4h2v-4z" />
    </>
  ),
  calendar: (
    <>
      <rect x="3" y="5" width="18" height="16" rx="2.5" />
      <path d="M3 10h18M8 3v4M16 3v4" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7.5v5l3 2.5" />
    </>
  ),
  check: <path d="M20 6L9 17l-5-5" />,
  close: <path d="M18 6L6 18M6 6l12 12" />,
  'arrow-right': <path d="M5 12h13M12 5l7 7-7 7" />,
  'arrow-left': <path d="M19 12H5M12 19l-7-7 7-7" />,
  'arrow-up': <path d="M12 19V5M5 12l7-7 7 7" />,
  search: (
    <>
      <circle cx="11" cy="11" r="7.5" />
      <path d="M21 21l-4.3-4.3" />
    </>
  ),
  filter: <path d="M4 6h16M7 12h10M10 18h4" />,
  bell: (
    <>
      <path d="M18 8a6 6 0 10-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" />
      <path d="M10.5 21a2 2 0 003 0" />
    </>
  ),
  lock: (
    <>
      <rect x="4" y="10" width="16" height="11" rx="2.5" />
      <path d="M8 10V7a4 4 0 018 0v3" />
    </>
  ),
  star: <path d="M12 2l2.6 7.2H22l-6 4.6 2.3 7.2-6.3-4.6L5.7 21 8 13.8 2 9.2h7.4z" />,
  spark: <path d="M12 2l2.6 7.2H22l-6 4.6 2.3 7.2-6.3-4.6L5.7 21 8 13.8 2 9.2h7.4z" />,
  refresh: (
    <>
      <path d="M21 12a9 9 0 11-3.5-7.1" />
      <path d="M21 3v5h-5" />
    </>
  ),
  eye: (
    <>
      <path d="M2 12s3.5-6.5 10-6.5S22 12 22 12s-3.5 6.5-10 6.5S2 12 2 12z" />
      <circle cx="12" cy="12" r="2.8" />
    </>
  ),
  upload: (
    <>
      <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
      <path d="M7 10l5-5 5 5M12 5v12" />
    </>
  ),
  trash: <path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14" />,
  image: (
    <>
      <rect x="3" y="3" width="18" height="18" rx="2.5" />
      <circle cx="8.5" cy="8.5" r="1.8" />
      <path d="M21 15l-5-5L5 21" />
    </>
  ),
  grid: (
    <>
      <rect x="3" y="3" width="7" height="7" rx="1.5" />
      <rect x="14" y="3" width="7" height="7" rx="1.5" />
      <rect x="3" y="14" width="7" height="7" rx="1.5" />
      <rect x="14" y="14" width="7" height="7" rx="1.5" />
    </>
  ),
  users: (
    <>
      <circle cx="9" cy="8" r="3.5" />
      <path d="M2 21v-1a7 7 0 0114 0v1M17 11a3 3 0 100-6" />
    </>
  ),
  settings: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.7 1.7 0 00.3 1.9l.1.1a2 2 0 01-2.8 2.8l-.1-.1a1.7 1.7 0 00-2.9 1.2V21a2 2 0 01-4 0v-.1A1.7 1.7 0 004 19.7l-.1.1a2 2 0 01-2.8-2.8l.1-.1A1.7 1.7 0 003 15a2 2 0 010-4" />
    </>
  ),
  trophy: (
    <>
      <path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 01-10 0z" />
      <path d="M17 5h3v2a3 3 0 01-3 3M7 5H4v2a3 3 0 003 3" />
    </>
  ),
  warning: (
    <>
      <path d="M12 9v5M12 17.5v.5" />
      <path d="M10.3 3.2L2.5 17a2 2 0 001.7 3h15.6a2 2 0 001.7-3L13.7 3.2a2 2 0 00-3.4 0z" />
    </>
  ),
  globe: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M3.5 9h17M3.5 15h17M12 3a14 14 0 000 18M12 3a14 14 0 010 18" />
    </>
  ),
  phone: (
    <>
      <rect x="6" y="2" width="12" height="20" rx="2.5" />
      <path d="M11 18h2" />
    </>
  ),
  plus: <path d="M12 5v14M5 12h14" />,
  logout: (
    <>
      <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4" />
      <path d="M16 17l5-5-5-5M21 12H9" />
    </>
  ),
  activity: <path d="M22 12h-4l-3 9L9 3l-3 9H2" />,
};

export default function Icon({ name, size = 18, className, label, strokeWidth = 2 }: Props) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      {...(label ? { role: 'img', 'aria-label': label } : { 'aria-hidden': true })}
    >
      {PATHS[name]}
    </svg>
  );
}

/**
 * Neutral geometric marks used when an AI model has no admin-uploaded logo.
 * Deliberately generic — we never ship copies of the real brand marks.
 */
export function ModelMark({ slug, size = 22 }: { slug: string; size?: number }) {
  const common = {
    width: size,
    height: size,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 1.6,
    'aria-hidden': true as const,
  };
  switch (slug) {
    case 'claude':
      return (
        <svg {...common}>
          <path d="M12 3l8 5v8l-8 5-8-5V8z" />
          <path d="M12 3v18M4 8l16 8M20 8L4 16" />
        </svg>
      );
    case 'gemini':
      return (
        <svg {...common}>
          <circle cx="12" cy="5" r="2.2" />
          <circle cx="5.5" cy="16" r="2.2" />
          <circle cx="18.5" cy="16" r="2.2" />
          <path d="M10.6 6.8L7 13.9M13.4 6.8L17 13.9M7.7 16h8.6" />
        </svg>
      );
    case 'chatgpt':
      return (
        <svg {...common}>
          <circle cx="12" cy="12" r="3" />
          <circle cx="12" cy="12" r="8.5" />
          <path d="M12 3.5v3M12 17.5v3M3.5 12h3M17.5 12h3" />
        </svg>
      );
    default:
      return (
        <svg {...common}>
          <rect x="4" y="4" width="16" height="16" rx="3.5" />
          <path d="M9 9h6v6H9z" />
        </svg>
      );
  }
}

/** The platform logo. */
export function Logo({ size = 27 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden="true">
      <rect x="2" y="2" width="28" height="28" rx="9.5" fill="url(#ath-logo-grad)" />
      <path d="M16 9L19.5 15.5L16 22L12.5 15.5L16 9Z" fill="white" fillOpacity="0.96" />
      <defs>
        <linearGradient id="ath-logo-grad" x1="2" y1="2" x2="30" y2="30">
          <stop stopColor="#7C8CFF" />
          <stop offset="1" stopColor="#00E0B4" />
        </linearGradient>
      </defs>
    </svg>
  );
}
