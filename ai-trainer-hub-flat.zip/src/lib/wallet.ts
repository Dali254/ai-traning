import type { PoolClient } from 'pg';
import { transaction, queryOne, query } from './db';

/**
 * Wallet accounting. Rules (PROJECT.md §5):
 *   1. wallet_transactions is append-only — a DB trigger enforces it.
 *   2. Every balance change happens inside a transaction with the wallet
 *      row locked FOR UPDATE, so concurrent task submissions can't race.
 *   3. Every row records balance_before and balance_after.
 *   4. Corrections are new reversing entries, never edits.
 */

export type LedgerType =
  | 'task_reward'
  | 'difficulty_bonus'
  | 'performance_bonus'
  | 'daily_bonus'
  | 'weekly_bonus'
  | 'first_task_bonus'
  | 'login_bonus'
  | 'streak_bonus'
  | 'level_up_bonus'
  | 'accuracy_bonus'
  | 'leaderboard_bonus'
  | 'referral_commission'
  | 'withdrawal'
  | 'withdrawal_fee'
  | 'withdrawal_reversal'
  | 'admin_credit'
  | 'admin_debit'
  | 'pending_release'
  | 'pending_hold';

export type Wallet = {
  id: number;
  user_id: number;
  available_balance: string;
  pending_balance: string;
  total_earned: string;
  total_withdrawn: string;
  total_bonuses: string;
};

const BONUS_TYPES = new Set<LedgerType>([
  'difficulty_bonus',
  'performance_bonus',
  'daily_bonus',
  'weekly_bonus',
  'first_task_bonus',
  'login_bonus',
  'streak_bonus',
  'level_up_bonus',
  'accuracy_bonus',
  'leaderboard_bonus',
]);

export async function createWallet(userId: number, client?: PoolClient): Promise<void> {
  const sql = `INSERT INTO wallets (user_id) VALUES ($1) ON CONFLICT (user_id) DO NOTHING`;
  if (client) await client.query(sql, [userId]);
  else await query(sql, [userId]);
}

export async function getWallet(userId: number): Promise<Wallet | null> {
  return queryOne<Wallet>('SELECT * FROM wallets WHERE user_id = $1', [userId]);
}

type PostArgs = {
  userId: number;
  type: LedgerType;
  amount: number;
  description: string;
  reference?: string | null;
  /** 'available' hits the spendable balance; 'pending' parks it until scored. */
  bucket?: 'available' | 'pending';
  /** Required for admin_credit / admin_debit. */
  reason?: string | null;
  createdBy?: number | null;
};

/**
 * Post one entry to the ledger and move the balance.
 * Pass an existing client to join a surrounding transaction.
 */
export async function post(args: PostArgs, client?: PoolClient): Promise<number> {
  const run = async (c: PoolClient) => postWithin(c, args);
  if (client) return run(client);
  return transaction(run);
}

async function postWithin(c: PoolClient, args: PostArgs): Promise<number> {
  const {
    userId,
    type,
    amount,
    description,
    reference = null,
    bucket = 'available',
    reason = null,
    createdBy = null,
  } = args;

  if (!Number.isFinite(amount) || amount < 0) {
    throw new Error(`Ledger amount must be a non-negative number, got ${amount}`);
  }
  if ((type === 'admin_credit' || type === 'admin_debit') && !reason) {
    throw new Error('Admin wallet adjustments require a reason');
  }

  const direction: 'credit' | 'debit' =
    type === 'withdrawal' || type === 'withdrawal_fee' || type === 'admin_debit' || type === 'pending_hold'
      ? 'debit'
      : 'credit';

  // Lock the wallet row so two submissions can't both read the same balance.
  const locked = await c.query<Wallet>(
    'SELECT * FROM wallets WHERE user_id = $1 FOR UPDATE',
    [userId]
  );
  let wallet = locked.rows[0];
  if (!wallet) {
    await c.query('INSERT INTO wallets (user_id) VALUES ($1) ON CONFLICT DO NOTHING', [userId]);
    const again = await c.query<Wallet>('SELECT * FROM wallets WHERE user_id = $1 FOR UPDATE', [userId]);
    wallet = again.rows[0];
  }

  const col = bucket === 'pending' ? 'pending_balance' : 'available_balance';
  const before = Number(bucket === 'pending' ? wallet.pending_balance : wallet.available_balance);
  const delta = direction === 'credit' ? amount : -amount;
  const after = round2(before + delta);

  if (after < 0) {
    throw new InsufficientFunds(
      `Insufficient ${bucket} balance: have ${before.toFixed(2)}, need ${amount.toFixed(2)}`
    );
  }

  // Ledger row first, so the audit trail exists even if the cache update fails.
  const inserted = await c.query<{ id: number }>(
    `INSERT INTO wallet_transactions
       (user_id, wallet_id, type, direction, amount, balance_before, balance_after,
        description, reference, status, created_by, reason)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'completed',$10,$11)
     RETURNING id`,
    [
      userId,
      wallet.id,
      type,
      direction,
      amount.toFixed(2),
      before.toFixed(2),
      after.toFixed(2),
      description,
      reference,
      createdBy,
      reason,
    ]
  );

  // Roll up the cached totals.
  const bumpEarned = direction === 'credit' && type !== 'withdrawal_reversal' ? amount : 0;
  const bumpWithdrawn = type === 'withdrawal' ? amount : 0;
  const bumpBonuses = BONUS_TYPES.has(type) ? amount : 0;

  await c.query(
    `UPDATE wallets SET
       ${col}          = $2,
       total_earned    = total_earned    + $3,
       total_withdrawn = total_withdrawn + $4,
       total_bonuses   = total_bonuses   + $5,
       updated_at      = now()
     WHERE id = $1`,
    [
      wallet.id,
      after.toFixed(2),
      bumpEarned.toFixed(2),
      bumpWithdrawn.toFixed(2),
      bumpBonuses.toFixed(2),
    ]
  );

  return inserted.rows[0].id;
}

/**
 * Move money from pending into available — used when a held reward is scored
 * and approved. Two ledger rows so both sides are visible.
 */
export async function releasePending(
  userId: number,
  amount: number,
  description: string,
  reference: string | null,
  client?: PoolClient
): Promise<void> {
  const run = async (c: PoolClient) => {
    await postWithin(c, {
      userId,
      type: 'pending_hold',
      amount,
      description: `Released: ${description}`,
      reference,
      bucket: 'pending',
    });
    await postWithin(c, {
      userId,
      type: 'pending_release',
      amount,
      description,
      reference,
      bucket: 'available',
    });
  };
  if (client) return run(client);
  await transaction(run);
}

export async function listTransactions(userId: number, limit = 50, offset = 0) {
  return query(
    `SELECT id, type, direction, amount, balance_before, balance_after,
            description, reference, status, created_at
       FROM wallet_transactions
      WHERE user_id = $1
      ORDER BY created_at DESC, id DESC
      LIMIT $2 OFFSET $3`,
    [userId, limit, offset]
  );
}

export class InsufficientFunds extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'InsufficientFunds';
  }
}

export function round2(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}
