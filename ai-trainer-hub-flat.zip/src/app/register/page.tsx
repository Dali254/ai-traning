import { Suspense } from 'react';
import { redirect } from 'next/navigation';
import { getUser } from '@/lib/session';
import { getMany } from '@/lib/settings';
import RegisterForm from './RegisterForm';

export const dynamic = 'force-dynamic';

export default async function RegisterPage({
  searchParams,
}: {
  searchParams: Promise<{ ref?: string }>;
}) {
  const user = await getUser();
  if (user) redirect(user.role === 'admin' ? '/admin' : '/dashboard');

  const { ref } = await searchParams;
  const settings = await getMany(['paid_membership', 'membership_fee', 'currency', 'referrals_enabled']);

  return (
    <Suspense>
      <RegisterForm
        referral={settings.referrals_enabled === 'true' ? (ref ?? '').toUpperCase() : ''}
        paidMembership={settings.paid_membership === 'true'}
        membershipFee={Number(settings.membership_fee || 0)}
        currency={settings.currency || 'KES'}
      />
    </Suspense>
  );
}
