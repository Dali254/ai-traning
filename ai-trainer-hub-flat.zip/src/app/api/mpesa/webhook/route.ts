import { NextResponse } from 'next/server';
import { transaction } from '@/lib/db';
import { verifyWebhook, mapStatus, type WebhookPayload } from '@/lib/mpesa';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * PesaFlux payment webhook.
 *
 * This is the ONLY place a membership payment becomes 'paid'. A button click
 * never does it (PROJECT.md §5.3).
 *
 * Idempotency: mpesa_transactions.transaction_id is UNIQUE, and we only act on
 * the row when its status actually changes pending → success. A retried
 * delivery therefore can't upgrade membership twice or double-credit.
 *
 * Always answer 200 once we've stored the result, otherwise the provider
 * retries for ~3 hours.
 */
export async function POST(req: Request) {
  // Raw text, not req.json() — the HMAC covers the exact bytes.
  const rawBody = await req.text();
  const sig = req.headers.get('x-pesaflux-signature');

  const verified = verifyWebhook(rawBody, sig);
  if (!verified.ok) {
    console.warn('[mpesa:webhook] rejected:', verified.reason);
    return NextResponse.json({ error: 'Invalid signature' }, { status: 401 });
  }

  let payload: WebhookPayload;
  try {
    payload = JSON.parse(rawBody) as WebhookPayload;
  } catch {
    return NextResponse.json({ error: 'Malformed JSON' }, { status: 400 });
  }

  if (!payload.transaction_id) {
    return NextResponse.json({ error: 'Missing transaction_id' }, { status: 400 });
  }

  const status = mapStatus(payload.status);

  try {
    await transaction(async (c) => {
      // Lock the row for this transaction, if we know about it.
      const existing = await c.query<{
        id: number;
        user_id: number | null;
        purpose: string;
        status: string;
        amount: string;
      }>(
        `SELECT id, user_id, purpose, status, amount
           FROM mpesa_transactions
          WHERE transaction_id = $1
          FOR UPDATE`,
        [payload.transaction_id]
      );

      const row = existing.rows[0];

      // Unknown transaction: record it so nothing is lost, then stop.
      // (Can happen if the provider replays something from another system.)
      if (!row) {
        await c.query(
          `INSERT INTO mpesa_transactions
             (transaction_id, direction, purpose, phone, amount, reference,
              status, mpesa_receipt, raw_callback, transaction_date, updated_at)
           VALUES ($1,'in','topup',$2,$3,$4,$5,$6,$7,$8, now())
           ON CONFLICT (transaction_id) DO NOTHING`,
          [
            payload.transaction_id,
            payload.msisdn ?? '',
            Number(payload.amount ?? 0).toFixed(2),
            payload.reference ?? null,
            status,
            payload.mpesa_receipt ?? null,
            JSON.stringify(payload),
            payload.transaction_date ?? null,
          ]
        );
        console.warn('[mpesa:webhook] unknown transaction stored:', payload.transaction_id);
        return;
      }

      // Already settled — a retry. Store the callback, change nothing.
      if (row.status !== 'pending') {
        await c.query(
          `UPDATE mpesa_transactions
              SET raw_callback = $2, updated_at = now()
            WHERE id = $1`,
          [row.id, JSON.stringify(payload)]
        );
        return;
      }

      await c.query(
        `UPDATE mpesa_transactions
            SET status = $2,
                mpesa_receipt = $3,
                result_desc = $4,
                raw_callback = $5,
                transaction_date = COALESCE($6, now()),
                updated_at = now()
          WHERE id = $1`,
        [
          row.id,
          status,
          payload.mpesa_receipt ?? null,
          payload.event ?? null,
          JSON.stringify(payload),
          payload.transaction_date ?? null,
        ]
      );

      if (status !== 'success' || !row.user_id) return;

      // ── Membership payment confirmed ──────────────────────────────
      if (row.purpose === 'membership') {
        await c.query(
          `UPDATE users
              SET membership_status = 'paid'
            WHERE id = $1 AND membership_status <> 'paid'`,
          [row.user_id]
        );

        await c.query(
          `INSERT INTO notifications (user_id, type, title, body)
           VALUES ($1, 'membership_payment', 'Membership activated',
                   'Your payment was confirmed. All earning tasks are now unlocked.')`,
          [row.user_id]
        );
      }
    });
  } catch (err) {
    // A 500 makes the provider retry, which is what we want on a DB blip.
    console.error('[mpesa:webhook] processing failed:', err);
    return NextResponse.json({ error: 'Processing failed' }, { status: 500 });
  }

  return NextResponse.json({ received: true }, { status: 200 });
}

/** Some providers probe with GET. Answer politely. */
export async function GET() {
  return NextResponse.json({ ok: true, endpoint: 'mpesa-webhook' });
}
