import crypto from 'node:crypto';

/**
 * M-Pesa via LipaLink / PesaFlux.
 *
 * The single API key is BOTH the X-Api-Key header value AND the HMAC secret
 * used to sign webhooks. It is read from the environment only — never written
 * to a file, never sent to the browser.
 */

function apiKey(): string {
  const k = process.env.PESAFLUX_API_KEY;
  if (!k) throw new MpesaError('PESAFLUX_API_KEY is not set');
  return k;
}

function businessId(): number {
  const b = process.env.PESAFLUX_BUSINESS_ID;
  if (!b) throw new MpesaError('PESAFLUX_BUSINESS_ID is not set');
  const n = Number(b);
  if (!Number.isInteger(n)) throw new MpesaError('PESAFLUX_BUSINESS_ID must be an integer');
  return n;
}

const STK_URL = process.env.PESAFLUX_STK_URL || 'https://lipalink.co.ke/api/stk_push.php';
const STATUS_URL =
  process.env.PESAFLUX_STATUS_URL || 'https://lipalink.co.ke/api/transaction_status.php';

export class MpesaError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'MpesaError';
  }
}

/**
 * Normalise a Kenyan number to 2547XXXXXXXX / 2541XXXXXXXX.
 * Accepts 0712…, +254712…, 254712…, 712….
 */
export function normalisePhone(input: string): string {
  const digits = input.replace(/\D/g, '');
  if (digits.startsWith('254') && digits.length === 12) return digits;
  if (digits.startsWith('0') && digits.length === 10) return `254${digits.slice(1)}`;
  if (digits.length === 9 && (digits.startsWith('7') || digits.startsWith('1'))) {
    return `254${digits}`;
  }
  throw new MpesaError(`"${input}" is not a valid Kenyan phone number`);
}

export function isValidPhone(input: string): boolean {
  try {
    normalisePhone(input);
    return true;
  } catch {
    return false;
  }
}

/** Display form: 0712 345 678 */
export function formatPhone(msisdn: string): string {
  const local = msisdn.startsWith('254') ? `0${msisdn.slice(3)}` : msisdn;
  return local.replace(/^(\d{4})(\d{3})(\d{3})$/, '$1 $2 $3');
}

// ─── STK push ───────────────────────────────────────────────────────────

export type StkResult =
  | { success: true; transactionId: string; message: string; raw: unknown }
  | { success: false; error: string; raw: unknown };

export async function stkPush(opts: {
  amount: number;
  phone: string;
  reference: string;
}): Promise<StkResult> {
  const msisdn = normalisePhone(opts.phone);
  const amount = Math.round(opts.amount);

  if (amount < 1) return { success: false, error: 'Amount must be at least KES 1', raw: null };

  const payload = {
    amount,
    msisdn,
    reference: opts.reference,
    business_id: businessId(),
  };

  let raw: unknown = null;
  try {
    const res = await fetch(STK_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Api-Key': apiKey(),
      },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(30_000),
    });

    const text = await res.text();
    try {
      raw = JSON.parse(text);
    } catch {
      raw = { httpStatus: res.status, body: text.slice(0, 500) };
      return { success: false, error: `Provider returned non-JSON (HTTP ${res.status})`, raw };
    }

    const body = raw as { success?: boolean; transaction_id?: string; message?: string; error?: string };

    if (body.success && body.transaction_id) {
      return {
        success: true,
        transactionId: body.transaction_id,
        message: body.message || 'STK push sent',
        raw,
      };
    }
    return { success: false, error: body.error || 'STK push failed', raw };
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Network error contacting M-Pesa provider';
    return { success: false, error: message, raw };
  }
}

// ─── Status check ───────────────────────────────────────────────────────

export type StatusResult =
  | {
      success: true;
      status: 'Pending' | 'Success' | 'Failed' | 'Expired' | string;
      transactionId: string;
      mpesaReceipt: string | null;
      amount: number | null;
      msisdn: string | null;
      reference: string | null;
      resultDesc: string | null;
      transactionDate: string | null;
      raw: unknown;
    }
  | { success: false; error: string; raw: unknown };

export async function checkStatus(transactionId: string): Promise<StatusResult> {
  let raw: unknown = null;
  try {
    const url = `${STATUS_URL}?transaction_id=${encodeURIComponent(transactionId)}`;
    const res = await fetch(url, {
      headers: { 'X-Api-Key': apiKey() },
      signal: AbortSignal.timeout(20_000),
    });

    const text = await res.text();
    try {
      raw = JSON.parse(text);
    } catch {
      return { success: false, error: `Provider returned non-JSON (HTTP ${res.status})`, raw: text.slice(0, 500) };
    }

    const b = raw as Record<string, unknown>;
    if (!b.success) {
      return { success: false, error: String(b.error ?? 'Status check failed'), raw };
    }

    return {
      success: true,
      status: String(b.status ?? 'Pending'),
      transactionId: String(b.transaction_id ?? transactionId),
      mpesaReceipt: b.mpesa_receipt ? String(b.mpesa_receipt) : null,
      amount: b.amount != null ? Number(b.amount) : null,
      msisdn: b.msisdn ? String(b.msisdn) : null,
      reference: b.reference ? String(b.reference) : null,
      resultDesc: b.result_desc ? String(b.result_desc) : null,
      transactionDate: b.transaction_date ? String(b.transaction_date) : null,
      raw,
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Network error checking status';
    return { success: false, error: message, raw };
  }
}

// ─── Webhook signature ──────────────────────────────────────────────────

/**
 * Verify an incoming PesaFlux webhook.
 *
 * Header:  X-Pesaflux-Signature: t=<unix>,v1=<hmac>
 * HMAC:    SHA-256 of "<t>.<raw body>" keyed with the API key.
 *
 * Pass the RAW request body text — not a re-serialised object, or the bytes
 * won't match and every webhook will be rejected.
 */
export function verifyWebhook(
  rawBody: string,
  signatureHeader: string | null,
  opts: { toleranceSec?: number } = {}
): { ok: true } | { ok: false; reason: string } {
  if (!signatureHeader) return { ok: false, reason: 'Missing X-Pesaflux-Signature header' };

  const parts: Record<string, string> = {};
  for (const chunk of signatureHeader.split(',')) {
    const [k, v] = chunk.split('=');
    if (k && v) parts[k.trim()] = v.trim();
  }

  const t = parts.t;
  const v1 = parts.v1;
  if (!t || !v1) return { ok: false, reason: 'Signature header missing t or v1' };

  const expected = crypto
    .createHmac('sha256', apiKey())
    .update(`${t}.${rawBody}`)
    .digest('hex');

  const a = Buffer.from(expected, 'utf8');
  const b = Buffer.from(v1, 'utf8');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return { ok: false, reason: 'Signature mismatch' };
  }

  // Replay guard. Default 15 min; provider retries over ~3h, so keep this
  // generous enough that a legitimate retry still verifies.
  const tolerance = opts.toleranceSec ?? 60 * 15;
  const age = Math.abs(Date.now() / 1000 - Number(t));
  if (!Number.isFinite(age)) return { ok: false, reason: 'Signature timestamp is not a number' };
  if (age > tolerance) return { ok: false, reason: `Signature timestamp too old (${Math.round(age)}s)` };

  return { ok: true };
}

export type WebhookPayload = {
  event: string;
  transaction_id: string;
  mpesa_receipt?: string;
  msisdn: string;
  amount: number;
  reference: string;
  business_id: number;
  status: string;
  redirected?: boolean;
  transaction_date?: string;
  country?: string;
};

/** Map the provider's status word to our enum. */
export function mapStatus(status: string): 'pending' | 'success' | 'failed' | 'expired' {
  const s = status.toLowerCase();
  if (s === 'success') return 'success';
  if (s === 'failed' || s === 'cancelled') return 'failed';
  if (s === 'expired' || s === 'timeout') return 'expired';
  return 'pending';
}
