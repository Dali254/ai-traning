import { NextResponse, type NextRequest } from 'next/server';
import { jwtVerify } from 'jose';

/**
 * Route protection. Runs on the Edge, so it only checks that a valid session
 * cookie exists — it does not touch the database. Pages and API routes still
 * load the user themselves (`getUser` / `requireUser`) and re-check role and
 * membership, so this is a fast first gate rather than the authority.
 */

const MEMBER_PREFIXES = ['/dashboard', '/tasks', '/withdraw', '/profile', '/leaderboard', '/pay'];
const ADMIN_PREFIX = '/admin';

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  const needsAuth =
    MEMBER_PREFIXES.some((p) => pathname === p || pathname.startsWith(`${p}/`)) ||
    pathname === ADMIN_PREFIX ||
    pathname.startsWith(`${ADMIN_PREFIX}/`);

  if (!needsAuth) return NextResponse.next();

  const token = req.cookies.get('ath_session')?.value;
  if (!token) return redirectToLogin(req);

  const secret = process.env.SESSION_SECRET;
  if (!secret) {
    // Misconfigured deploy — fail closed rather than letting everyone in.
    console.error('[middleware] SESSION_SECRET is not set');
    return redirectToLogin(req);
  }

  try {
    await jwtVerify(token, new TextEncoder().encode(secret));
  } catch {
    const res = redirectToLogin(req);
    res.cookies.delete('ath_session');
    return res;
  }

  return NextResponse.next();
}

function redirectToLogin(req: NextRequest) {
  const url = req.nextUrl.clone();
  url.pathname = '/login';
  url.search = `?next=${encodeURIComponent(req.nextUrl.pathname)}`;
  return NextResponse.redirect(url);
}

export const config = {
  matcher: [
    '/dashboard/:path*',
    '/tasks/:path*',
    '/withdraw/:path*',
    '/profile/:path*',
    '/leaderboard/:path*',
    '/pay/:path*',
    '/admin/:path*',
  ],
};
