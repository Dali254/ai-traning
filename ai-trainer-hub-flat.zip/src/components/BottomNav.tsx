'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import Icon, { type IconName } from './Icon';

const ITEMS: { href: string; label: string; icon: IconName }[] = [
  { href: '/dashboard', label: 'Home', icon: 'home' },
  { href: '/tasks', label: 'Tasks', icon: 'tasks' },
  { href: '/withdraw', label: 'Earnings', icon: 'money' },
  { href: '/profile', label: 'Profile', icon: 'user' },
];

/**
 * Mobile bottom navigation. Fixed, so every page body carries
 * `padding-bottom` to keep content clear of it (PROJECT.md §3).
 */
export default function BottomNav() {
  const path = usePathname();

  return (
    <nav
      className="chrome-bottom"
      style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        zIndex: 40,
        display: 'flex',
        padding: '8px 8px 20px',
        maxWidth: 520,
        margin: '0 auto',
      }}
    >
      {ITEMS.map((item) => {
        const active = path === item.href || path.startsWith(`${item.href}/`);
        return (
          <Link
            key={item.href}
            href={item.href}
            aria-current={active ? 'page' : undefined}
            style={{
              flex: 1,
              minHeight: 48,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 4,
              borderRadius: 12,
              color: active ? 'var(--accent-1-lt)' : '#656d85',
            }}
          >
            <Icon name={item.icon} size={20} strokeWidth={2.1} />
            <span style={{ fontSize: 9, fontWeight: active ? 800 : 600 }}>{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
