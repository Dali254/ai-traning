import type { PoolClient } from 'pg';
import { getBool, getNumber, getSetting } from './settings';
import { post, round2 } from './wallet';

/**
 * The one place a reward is calculated. Every earning path goes through
 * `computeReward` so the number a member sees on a task card is the same
 * number that reaches their wallet.
 *
 * Admin can switch any component off without a code change — see the
 * `commission_*` and `bonus_*` settings.
 */

export type RewardInput = {
  /** Reward from the task's difficulty level (or the task's own override). */
  baseReward: number;
  /** Difficulty-level bonus, if the difficulty defines one. */
  difficultyBonus: number;
  /** Multiplier from the member's level (e.g. 1.20 for Advanced). */
  levelMultiplier: number;
  /** Multiplier from the difficulty row. */
  difficultyMultiplier: number;
  /** Score 0–100 from quality control, or null when unscored. */
  score: number | null;
};

export type RewardBreakdown = {
  base: number;
  difficultyBonus: number;
  taskCommission: number;
  performanceBonus: number;
  levelAdjustment: number;
  qualityPenalty: number;
  total: number;
  /** Lines to write to the ledger, in order. */
  lines: { type: Parameters<typeof post>[0]['type']; amount: number; label: string }[];
  /** Whether quality control rejected the submission outright. */
  rejected: boolean;
};

export async function computeReward(input: RewardInput): Promise<RewardBreakdown> {
  const mode = await getSetting('reward_mode', 'fixed');
  const rewardPct = await getNumber('reward_percentage', 10);

  const minScore = await getNumber('min_passing_score', 60);
  const lowAction = await getSetting('low_quality_action', 'reduce');
  const lowRate = await getNumber('low_quality_rate', 50);

  // ── Base ────────────────────────────────────────────────────────────
  // 'fixed'      → the difficulty level's reward
  // 'percentage' → a rate applied to that reward, for operators who prefer
  //                to express everything as a percentage of a notional value
  let base = mode === 'percentage' ? input.baseReward * (rewardPct / 100) : input.baseReward;
  base = round2(base);

  const lines: RewardBreakdown['lines'] = [];
  let rejected = false;
  let qualityPenalty = 0;

  // ── Quality control ────────────────────────────────────────────────
  if (input.score !== null && input.score < minScore) {
    if (lowAction === 'reject') {
      return {
        base: 0,
        difficultyBonus: 0,
        taskCommission: 0,
        performanceBonus: 0,
        levelAdjustment: 0,
        qualityPenalty: base,
        total: 0,
        lines: [],
        rejected: true,
      };
    }
    if (lowAction === 'reduce') {
      const reduced = round2(base * (lowRate / 100));
      qualityPenalty = round2(base - reduced);
      base = reduced;
    }
  }

  // ── Level and difficulty multipliers ───────────────────────────────
  const multiplier = (input.levelMultiplier || 1) * (input.difficultyMultiplier || 1);
  const multiplied = round2(base * multiplier);
  const levelAdjustment = round2(multiplied - base);
  base = multiplied;

  if (base > 0) lines.push({ type: 'task_reward', amount: base, label: 'Task reward' });

  // ── Difficulty bonus ───────────────────────────────────────────────
  let difficultyBonus = 0;
  if (input.difficultyBonus > 0 && (await getBool('bonus_difficulty', true))) {
    difficultyBonus = round2(input.difficultyBonus);
    lines.push({ type: 'difficulty_bonus', amount: difficultyBonus, label: 'Difficulty bonus' });
  }

  // ── Task completion commission ─────────────────────────────────────
  let taskCommission = 0;
  if (await getBool('commission_task', true)) {
    const rate = await getNumber('commission_task_rate', 0);
    if (rate > 0) {
      taskCommission = round2(base * (rate / 100));
      if (taskCommission > 0) {
        lines.push({ type: 'task_reward', amount: taskCommission, label: 'Task commission' });
      }
    }
  }

  // ── Performance bonus, paid on high scores ─────────────────────────
  let performanceBonus = 0;
  if (input.score !== null && (await getBool('bonus_performance', true))) {
    const rate = await getNumber('bonus_performance_rate', 10);
    const threshold = await getNumber('bonus_accuracy_min', 95);
    if (rate > 0 && input.score >= threshold) {
      performanceBonus = round2(base * (rate / 100));
      if (performanceBonus > 0) {
        lines.push({ type: 'performance_bonus', amount: performanceBonus, label: 'Performance bonus' });
      }
    }
  }

  const total = round2(base + difficultyBonus + taskCommission + performanceBonus);

  return {
    base,
    difficultyBonus,
    taskCommission,
    performanceBonus,
    levelAdjustment,
    qualityPenalty,
    total,
    lines,
    rejected,
  };
}

/**
 * Write a computed reward to the ledger. Call inside the same transaction
 * that marks the submission, so a crash can't pay twice or lose the payment.
 */
export async function payReward(
  client: PoolClient,
  userId: number,
  breakdown: RewardBreakdown,
  reference: string,
  taskTitle: string
): Promise<void> {
  const holdPending = await getBool('hold_rewards_pending', true);
  const bucket = holdPending ? 'pending' : 'available';

  for (const line of breakdown.lines) {
    await post(
      {
        userId,
        type: line.type,
        amount: line.amount,
        description: `${line.label} — ${taskTitle}`,
        reference,
        bucket,
      },
      client
    );
  }
}

/** Referral cut on a member's earning, if referrals are on. */
export async function payReferralCommission(
  client: PoolClient,
  referrerId: number,
  earnerName: string,
  earnedAmount: number,
  reference: string
): Promise<number> {
  if (!(await getBool('referrals_enabled', true))) return 0;

  const rate = await getNumber('referral_rate', 5);
  const fixed = await getNumber('referral_fixed', 0);
  const cap = await getNumber('referral_max_earnings', 0);

  let amount = round2(earnedAmount * (rate / 100) + fixed);
  if (amount <= 0) return 0;

  if (cap > 0) {
    const rows = await client.query<{ total: string }>(
      `SELECT COALESCE(SUM(amount), 0) AS total
         FROM wallet_transactions
        WHERE user_id = $1 AND type = 'referral_commission'`,
      [referrerId]
    );
    const earnedSoFar = Number(rows.rows[0]?.total ?? 0);
    const remaining = round2(cap - earnedSoFar);
    if (remaining <= 0) return 0;
    amount = Math.min(amount, remaining);
  }

  await post(
    {
      userId: referrerId,
      type: 'referral_commission',
      amount,
      description: `Referral commission — ${earnerName}`,
      reference,
      bucket: 'available',
    },
    client
  );

  await client.query(
    `UPDATE referrals SET total_earned = total_earned + $2
      WHERE referrer_id = $1 AND referred_id = (
        SELECT id FROM users WHERE full_name = $3 LIMIT 1
      )`,
    [referrerId, amount.toFixed(2), earnerName]
  );

  return amount;
}
