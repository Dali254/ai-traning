import { query, queryOne } from './db';

/**
 * Every tunable value lives in the `settings` table so admin can change it
 * without a deploy. Nothing in app code hardcodes an amount, rate or switch.
 */

export type SettingRow = {
  key: string;
  value: string;
  value_type: 'string' | 'number' | 'boolean' | 'json';
  category: string;
  label: string | null;
};

// Per-request cache. Serverless invocations are short, so this is just
// deduplication within one request rather than a long-lived cache.
let cache: Map<string, SettingRow> | null = null;
let cachedAt = 0;
const TTL_MS = 5_000;

async function load(): Promise<Map<string, SettingRow>> {
  const now = Date.now();
  if (cache && now - cachedAt < TTL_MS) return cache;
  const rows = await query<SettingRow>(
    'SELECT key, value, value_type, category, label FROM settings'
  );
  cache = new Map(rows.map((r) => [r.key, r]));
  cachedAt = now;
  return cache;
}

export function invalidateSettings(): void {
  cache = null;
  cachedAt = 0;
}

export async function getAllSettings(): Promise<SettingRow[]> {
  const map = await load();
  return [...map.values()];
}

export async function getSettingsByCategory(category: string): Promise<SettingRow[]> {
  const map = await load();
  return [...map.values()].filter((r) => r.category === category);
}

/** Raw string value, or the fallback when the key is missing. */
export async function getSetting(key: string, fallback = ''): Promise<string> {
  const map = await load();
  return map.get(key)?.value ?? fallback;
}

export async function getNumber(key: string, fallback = 0): Promise<number> {
  const raw = await getSetting(key, '');
  if (raw === '') return fallback;
  const n = Number(raw);
  return Number.isFinite(n) ? n : fallback;
}

export async function getBool(key: string, fallback = false): Promise<boolean> {
  const raw = await getSetting(key, '');
  if (raw === '') return fallback;
  return raw === 'true' || raw === '1';
}

export async function getJson<T>(key: string, fallback: T): Promise<T> {
  const raw = await getSetting(key, '');
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

/**
 * Fetch many keys at once as a plain object — handy in pages that need a
 * dozen values and shouldn't make a dozen calls.
 */
export async function getMany(keys: string[]): Promise<Record<string, string>> {
  const map = await load();
  const out: Record<string, string> = {};
  for (const k of keys) out[k] = map.get(k)?.value ?? '';
  return out;
}

/**
 * Write a setting. Returns the previous value so the caller can write an
 * audit row — admin changes to economics must always be traceable.
 */
export async function setSetting(key: string, value: string): Promise<string | null> {
  const prev = await queryOne<{ value: string }>('SELECT value FROM settings WHERE key = $1', [key]);
  await query(
    `INSERT INTO settings (key, value, updated_at) VALUES ($1, $2, now())
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`,
    [key, value]
  );
  invalidateSettings();
  return prev?.value ?? null;
}
