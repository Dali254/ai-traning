import Link from 'next/link';
import { redirect } from 'next/navigation';
import { query } from '@/lib/db';
import { getMany } from '@/lib/settings';
import { getUser } from '@/lib/session';
import { moneyShort, money } from '@/lib/fmt';
import Icon, { Logo, ModelMark } from '@/components/Icon';

export const dynamic = 'force-dynamic';

type ModelRow = { slug: string; name: string; logo_path: string | null; accent: string };

export default async function LandingPage() {
  const user = await getUser();
  if (user) redirect(user.role === 'admin' ? '/admin' : '/dashboard');

  const [models, settings, stats] = await Promise.all([
    query<ModelRow>(
      `SELECT slug, name, logo_path, accent FROM ai_models
        WHERE visible = true ORDER BY sort_order, id LIMIT 4`
    ),
    getMany(['platform_name', 'currency', 'payout_cycle', 'paid_membership', 'membership_fee']),
    query<{ members: string; tasks_done: string; paid_out: string; avg_reward: string }>(
      `SELECT
         (SELECT COUNT(*)::text FROM users WHERE role = 'member' AND account_status = 'active') AS members,
         (SELECT COUNT(*)::text FROM submissions WHERE status <> 'rejected')                    AS tasks_done,
         (SELECT COALESCE(SUM(net_amount),0)::text FROM withdrawals WHERE status = 'paid')      AS paid_out,
         (SELECT COALESCE(AVG(reward),0)::text FROM difficulty_levels WHERE active = true)      AS avg_reward`
    ),
  ]);

  const cur = settings.currency || 'KES';
  const s = stats[0];
  const cycleLabel =
    settings.payout_cycle === 'daily'
      ? 'Daily'
      : settings.payout_cycle === 'weekly'
        ? 'Weekly'
        : 'Monthly';

  return (
    <main style={{ position: 'relative', minHeight: '100dvh', overflowX: 'hidden' }}>
      {/* ambient glow */}
      <div
        className="glow"
        style={{
          top: -200,
          left: -140,
          width: 520,
          height: 520,
          background: 'radial-gradient(circle, rgba(94,92,255,0.3) 0%, rgba(94,92,255,0) 68%)',
        }}
      />
      <div
        className="glow"
        style={{
          top: 120,
          right: -170,
          width: 460,
          height: 460,
          background: 'radial-gradient(circle, rgba(0,224,180,0.2) 0%, rgba(0,224,180,0) 68%)',
        }}
      />

      {/* header */}
      <header
        className="chrome-top"
        style={{
          position: 'sticky',
          top: 0,
          zIndex: 30,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '14px 18px',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <Logo />
          <span style={{ fontSize: 14.5, fontWeight: 800, letterSpacing: '-0.022em' }}>
            {settings.platform_name || 'AI Trainer Hub'}
          </span>
        </div>
        <Link
          href="/login"
          style={{ fontSize: 13.5, fontWeight: 650, color: 'var(--text-dim)', padding: '10px 6px' }}
        >
          Log in
        </Link>
      </header>

      {/* hero */}
      <section
        style={{
          position: 'relative',
          zIndex: 1,
          padding: '26px 20px 0',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          textAlign: 'center',
          maxWidth: 520,
          margin: '0 auto',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            padding: '7px 14px',
            borderRadius: 999,
            background: 'var(--accent-1-soft)',
            border: '1px solid var(--accent-1-line)',
            fontSize: 11,
            fontWeight: 700,
            color: '#c5cbff',
          }}
        >
          <span
            style={{
              width: 6,
              height: 6,
              borderRadius: '50%',
              background: 'var(--accent-2)',
              boxShadow: '0 0 9px rgba(0,224,180,0.9)',
            }}
          />
          <span className="num">{Number(s.members).toLocaleString('en-KE')}</span> members training
        </div>

        <h1
          style={{
            margin: '19px 0 0',
            fontSize: 36,
            lineHeight: 1.06,
            fontWeight: 900,
            letterSpacing: '-0.035em',
          }}
        >
          TRAIN AI.
          <br />
          COMPLETE TASKS.
          <br />
          <span
            style={{
              background: 'linear-gradient(118deg,#8E9BFF 0%,#00E0B4 100%)',
              WebkitBackgroundClip: 'text',
              backgroundClip: 'text',
              color: 'transparent',
            }}
          >
            EARN REWARDS.
          </span>
        </h1>

        <p
          style={{
            margin: '14px 0 0',
            fontSize: 14,
            lineHeight: 1.64,
            color: 'var(--text-dim)',
            maxWidth: 320,
          }}
        >
          Complete intelligent evaluation tasks and earn rewards based on your performance. Paid
          straight to M&#8209;Pesa.
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 9, width: '100%', marginTop: 22 }}>
          <Link href="/register" className="btn-primary" style={{ textAlign: 'center', fontSize: 15 }}>
            {settings.paid_membership === 'true'
              ? `Join for ${money(Number(settings.membership_fee || 0), cur)}`
              : 'Start Earning Free'}
          </Link>
          <Link href="#how" className="btn-ghost" style={{ textAlign: 'center', fontSize: 15 }}>
            See How It Works
          </Link>
        </div>

        {/* model logo slots — admin-uploaded, neutral mark as fallback */}
        <div style={{ width: '100%', marginTop: 26 }}>
          <div
            style={{
              fontSize: 9,
              fontWeight: 800,
              letterSpacing: '0.16em',
              color: '#565e78',
              marginBottom: 12,
            }}
          >
            EVALUATE RESPONSES FROM
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0,1fr))', gap: 7 }}>
            {models.map((m) => (
              <div
                key={m.slug}
                className="glass"
                style={{
                  padding: '13px 4px 10px',
                  borderRadius: 14,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: 8,
                }}
              >
                <span style={{ color: m.accent, display: 'flex' }}>
                  {m.logo_path ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={m.logo_path}
                      alt=""
                      width={22}
                      height={22}
                      style={{ objectFit: 'contain' }}
                    />
                  ) : (
                    <ModelMark slug={m.slug} />
                  )}
                </span>
                <span style={{ fontSize: 9, fontWeight: 700, color: '#aab3c6' }}>{m.name}</span>
              </div>
            ))}
            {models.length < 4 && (
              <div
                className="glass"
                style={{
                  padding: '13px 4px 10px',
                  borderRadius: 14,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: 8,
                  color: '#c99cf5',
                }}
              >
                <Icon name="plus" size={22} strokeWidth={1.7} />
                <span style={{ fontSize: 9, fontWeight: 700, color: '#aab3c6' }}>more soon</span>
              </div>
            )}
          </div>
        </div>

        {/* metrics */}
        <div style={{ width: '100%', display: 'flex', gap: 7, marginTop: 12 }}>
          <div className="glass" style={{ flex: 1, padding: '13px 11px', borderRadius: 14, textAlign: 'left' }}>
            <div style={tileLabel}>AVG / TASK</div>
            <div className="num" style={{ ...tileValue, color: 'var(--accent-2)' }}>
              {money(Math.round(Number(s.avg_reward)), cur)}
            </div>
          </div>
          <div className="glass" style={{ flex: 1, padding: '13px 11px', borderRadius: 14, textAlign: 'left' }}>
            <div style={tileLabel}>PAID OUT</div>
            <div className="num" style={tileValue}>
              {moneyShort(Number(s.paid_out), cur)}
            </div>
          </div>
          <div
            className="glass-money"
            style={{ flex: 1, padding: '13px 11px', borderRadius: 14, textAlign: 'left' }}
          >
            <div style={{ ...tileLabel, color: '#4fcfae' }}>PAYOUTS</div>
            <div style={{ ...tileValue, letterSpacing: '-0.025em' }}>{cycleLabel}</div>
          </div>
        </div>
      </section>

      {/* how it works */}
      <section
        id="how"
        style={{ padding: '44px 20px 40px', maxWidth: 520, margin: '0 auto', position: 'relative', zIndex: 1 }}
      >
        <h2 style={{ margin: 0, fontSize: 22, fontWeight: 850, letterSpacing: '-0.03em' }}>
          How it works
        </h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 18 }}>
          {[
            {
              n: 1,
              t: 'Create your account',
              d: 'Four details and you are in. No card needed to start.',
            },
            {
              n: 2,
              t: 'Get your daily tasks',
              d: 'A fresh set is assigned each day. You never repeat a task you have already seen.',
            },
            {
              n: 3,
              t: 'Evaluate and submit',
              d: 'Compare responses, rate prompts, check facts. Each task shows its reward up front.',
            },
            {
              n: 4,
              t: 'Get paid to M-Pesa',
              d: `Request a withdrawal any time. Payouts settle on the ${cycleLabel.toLowerCase()} cycle.`,
            },
          ].map((step) => (
            <div
              key={step.n}
              className="glass"
              style={{ padding: 15, borderRadius: 16, display: 'flex', gap: 13 }}
            >
              <div
                className="num"
                style={{
                  width: 28,
                  height: 28,
                  borderRadius: 9,
                  background: 'var(--accent-1-soft)',
                  color: '#a9b2ff',
                  fontSize: 12.5,
                  fontWeight: 900,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0,
                }}
              >
                {step.n}
              </div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 800, letterSpacing: '-0.022em' }}>{step.t}</div>
                <div style={{ fontSize: 12, lineHeight: 1.55, color: 'var(--text-faint)', marginTop: 3 }}>
                  {step.d}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div
          style={{
            marginTop: 18,
            padding: '13px 15px',
            borderRadius: 14,
            background: 'rgba(255,255,255,0.022)',
            border: '1px solid var(--border)',
            display: 'flex',
            gap: 10,
          }}
        >
          <span style={{ color: 'var(--text-faint)', flexShrink: 0, marginTop: 1 }}>
            <Icon name="lock" size={15} />
          </span>
          <p style={{ margin: 0, fontSize: 11, lineHeight: 1.55, color: '#8e98ae' }}>
            This is AI evaluation and human-feedback work — rating responses, checking facts and
            annotating data. Members do not modify any AI provider&apos;s models.
          </p>
        </div>

        <Link
          href="/register"
          className="btn-primary"
          style={{ display: 'block', textAlign: 'center', marginTop: 20, fontSize: 15 }}
        >
          Create your account
        </Link>
      </section>
    </main>
  );
}

const tileLabel: React.CSSProperties = {
  fontSize: 8.5,
  color: 'var(--label)',
  fontWeight: 800,
  letterSpacing: '0.11em',
  marginBottom: 6,
};

const tileValue: React.CSSProperties = {
  fontSize: 17,
  fontWeight: 850,
};
