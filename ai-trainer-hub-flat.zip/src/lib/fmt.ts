/** Formatting helpers. Currency code comes from settings, default KES. */

export function money(amount: number | string, currency = 'KES'): string {
  const n = typeof amount === 'string' ? Number(amount) : amount;
  if (!Number.isFinite(n)) return `${currency} 0`;
  const hasCents = Math.abs(n % 1) > 0.004;
  return `${currency} ${n.toLocaleString('en-KE', {
    minimumFractionDigits: hasCents ? 2 : 0,
    maximumFractionDigits: hasCents ? 2 : 0,
  })}`;
}

/** Compact form for stat tiles: KES 38M, KES 48k */
export function moneyShort(amount: number | string, currency = 'KES'): string {
  const n = typeof amount === 'string' ? Number(amount) : amount;
  if (!Number.isFinite(n)) return `${currency} 0`;
  if (Math.abs(n) >= 1_000_000) return `${currency} ${(n / 1_000_000).toFixed(1)}M`;
  if (Math.abs(n) >= 10_000) return `${currency} ${Math.round(n / 1000)}k`;
  return money(n, currency);
}

export function num(n: number | string): string {
  const v = typeof n === 'string' ? Number(n) : n;
  return Number.isFinite(v) ? v.toLocaleString('en-KE') : '0';
}

export function pct(n: number | string, digits = 1): string {
  const v = typeof n === 'string' ? Number(n) : n;
  return Number.isFinite(v) ? `${v.toFixed(digits)}%` : '0%';
}

/** EAT (UTC+3) — the platform's operating timezone. */
export const EAT_OFFSET_MS = 3 * 60 * 60 * 1000;

/** Today's date in EAT, as YYYY-MM-DD. This is the task-rotation "day". */
export function eatToday(now: Date = new Date()): string {
  return new Date(now.getTime() + EAT_OFFSET_MS).toISOString().slice(0, 10);
}

export function eatNow(now: Date = new Date()): Date {
  return new Date(now.getTime() + EAT_OFFSET_MS);
}

export function dayLabel(iso: string): string {
  const d = new Date(`${iso}T00:00:00Z`);
  return d.toLocaleDateString('en-GB', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    timeZone: 'UTC',
  });
}

export function dateLabel(value: string | Date): string {
  const d = typeof value === 'string' ? new Date(value) : value;
  return d.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    timeZone: 'Africa/Nairobi',
  });
}

export function timeLabel(value: string | Date): string {
  const d = typeof value === 'string' ? new Date(value) : value;
  return d.toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'Africa/Nairobi',
  });
}

/** "in 28 days", "in 9h 36m", "today" */
export function untilLabel(target: Date, from: Date = new Date()): string {
  const ms = target.getTime() - from.getTime();
  if (ms <= 0) return 'now';
  const mins = Math.floor(ms / 60_000);
  const hours = Math.floor(mins / 60);
  const days = Math.floor(hours / 24);
  if (days >= 1) return `in ${days} day${days === 1 ? '' : 's'}`;
  if (hours >= 1) return `in ${hours}h ${mins % 60}m`;
  return `in ${mins}m`;
}

export function countdown(target: Date, from: Date = new Date()): string {
  const ms = Math.max(0, target.getTime() - from.getTime());
  const total = Math.floor(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}h ${String(m).padStart(2, '0')}m`;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}
