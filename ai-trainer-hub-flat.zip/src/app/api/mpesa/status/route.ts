import { NextResponse } from 'next/server';
import { queryOne, transaction } from '@/lib/db';
import { requireUser, AuthError } from '@/lib/session';
import { checkStatus, mapStatus } from '@/lib/mpesa';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * Poll a payment's status. The payment page calls this every few seconds while
 * waiting for the member to approve the prompt.
 *
 * The webhook is the primary confirmation path; this is the fallback for when
 * a webhook is delayed or the member is staring at the screen. It applies the
 * same state change, guarded the same way, so whichever arrives first wins and
 * the second is a no-op.
 */
export async function GET(req: Request) {
  let user;
  try {
    user = await requireUser();
  } catch (err) {
    const status = err instanceof AuthError ? err.status : 401;
    return NextResponse.json({ error: 'Not signed in' }, { status });
  }

  const txId = new URL(req.url).searchParams.get('transaction_id');
  if (!txId) {
    return NextResponse.json({ error: 'transaction_id is required' }, { status: 400 });
  }

  // Only let a member poll their own payment.
  const row = await queryOne<{ id: number; status: string; purpose: string }>(
    `SELECT id, status, purpose FROM mpesa_transactions
      WHERE transaction_id = $1 AND user_id = $2`,
    [txId, user.id]
  );
  if (!row) {
    return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
  }

  // Already settled — report and stop. No provider call needed.
  if (row.status !== 'pending') {
    return NextResponse.json({ status: row.status, settled: true });
  }

  const result = await checkStatus(txId);
  if (!result.success) {
    // Provider unreachable: stay pending, let the client keep polling.
    return NextResponse.json({ status: 'pending', settled: false, note: result.error });
  }

  const mapped = mapStatus(result.status);
  if (mapped === 'pending') {
    return NextResponse.json({ status: 'pending', settled: false });
  }

  await transaction(async (c) => {
    const locked = await c.query<{ id: number; status: string; user_id: number | null; purpose: string }>(
      `SELECT id, status, user_id, purpose FROM mpesa_transactions WHERE id = $1 FOR UPDATE`,
      [row.id]
    );
    const tx = locked.rows[0];
    if (!tx || tx.status !== 'pending') return; // webhook got here first

    await c.query(
      `UPDATE mpesa_transactions
          SET status = $2, mpesa_receipt = $3, result_desc = $4,
              transaction_date = COALESCE($5, now()), updated_at = now()
        WHERE id = $1`,
      [tx.id, mapped, result.mpesaReceipt, result.resultDesc, result.transactionDate]
    );

    if (mapped === 'success' && tx.user_id && tx.purpose === 'membership') {
      await c.query(
        `UPDATE users SET membership_status = 'paid'
          WHERE id = $1 AND membership_status <> 'paid'`,
        [tx.user_id]
      );
      await c.query(
        `INSERT INTO notifications (user_id, type, title, body)
         VALUES ($1, 'membership_payment', 'Membership activated',
                 'Your payment was confirmed. All earning tasks are now unlocked.')`,
        [tx.user_id]
      );
    }
  });

  return NextResponse.json({
    status: mapped,
    settled: true,
    mpesaReceipt: result.mpesaReceipt,
  });
}
